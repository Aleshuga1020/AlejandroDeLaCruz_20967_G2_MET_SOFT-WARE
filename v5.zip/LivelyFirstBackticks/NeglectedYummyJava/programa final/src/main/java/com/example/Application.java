
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.example", "controllers", "services", "models"})
@EntityScan(basePackages = {"models"})
public class Application {
    public static void main(String[] args) {
        System.setProperty("server.port", "5000");
        System.setProperty("server.address", "0.0.0.0");
        
        var context = SpringApplication.run(Application.class, args);
        
        // Activar envío real de emails al iniciar la aplicación
        var emailService = context.getBean(services.EmailService.class);
        emailService.activarEnvioReal();
        
        System.out.println("=== SISTEMA DE MENSAJERÍA INICIADO ===");
        System.out.println("Envío de emails ACTIVADO con Gmail");
        System.out.println("Servidor corriendo en puerto 5000");
        System.out.println("=====================================");
    }
}
