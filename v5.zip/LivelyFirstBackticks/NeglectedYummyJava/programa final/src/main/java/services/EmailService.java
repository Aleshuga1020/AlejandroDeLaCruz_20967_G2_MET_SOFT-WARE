
package services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired(required = false)
    private JavaMailSender mailSender;
    
    private boolean modoSimulacion = false; // Activado para envío real

    public void enviarEmail(String destinatario, String asunto, String contenido) {
        if (modoSimulacion || mailSender == null) {
            // Modo simulación - solo registra en consola
            System.out.println("=== SIMULACIÓN DE EMAIL ===");
            System.out.println("Para: " + destinatario);
            System.out.println("Asunto: " + asunto);
            System.out.println("Contenido: " + contenido);
            System.out.println("========================");
            return;
        }
        
        try {
            SimpleMailMessage mensaje = new SimpleMailMessage();
            mensaje.setFrom("valeriita963@gmail.com");
            mensaje.setTo(destinatario);
            mensaje.setSubject(asunto);
            mensaje.setText(contenido);
            
            mailSender.send(mensaje);
            System.out.println("Email enviado exitosamente a: " + destinatario);
        } catch (Exception e) {
            System.err.println("Error enviando email a " + destinatario + ": " + e.getMessage());
            // En lugar de lanzar excepción, registramos el error y continuamos
            System.out.println("Continuando en modo simulación para: " + destinatario);
        }
    }
    
    public void activarEnvioReal() {
        this.modoSimulacion = false;
    }
    
    public void activarModoSimulacion() {
        this.modoSimulacion = true;
    }
}
