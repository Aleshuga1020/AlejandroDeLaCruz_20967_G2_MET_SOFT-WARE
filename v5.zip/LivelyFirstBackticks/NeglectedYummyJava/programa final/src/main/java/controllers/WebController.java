
package controllers;

import models.*;
import services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class WebController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private MensajeService mensajeService;

    @Autowired
    private EnvioService envioService;

    @Autowired
    private EstadisticaService estadisticaService;

    @Autowired
    private FechasConmemorativasService fechasService;

    @GetMapping("/")
    public String index() {
        return "login";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public String procesarLogin(@RequestParam String username, 
                               @RequestParam String password,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        Usuario usuario = usuarioService.validarCredenciales(username, password);
        if (usuario != null) {
            session.setAttribute("usuario", usuario);
            return "redirect:/dashboard";
        } else {
            redirectAttributes.addFlashAttribute("error", "Credenciales incorrectas");
            return "redirect:/login";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Map<String, Object> estadisticas = estadisticaService.obtenerEstadisticasGenerales();
        model.addAttribute("estadisticas", estadisticas);
        return "dashboard";
    }

    @GetMapping("/clientes")
    public String clientes(@RequestParam(value = "buscar", required = false) String buscarTermino,
                          @RequestParam(value = "estado", required = false) String estadoFiltro,
                          Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<Cliente> clientes;

        if (buscarTermino != null && !buscarTermino.trim().isEmpty()) {
            clientes = clienteService.buscarClientes(buscarTermino);
        } else {
            clientes = clienteService.obtenerTodosLosClientes();
        }

        if (estadoFiltro != null && !estadoFiltro.trim().isEmpty()) {
            clientes = clientes.stream()
                    .filter(c -> c.getEstado().equalsIgnoreCase(estadoFiltro.trim()))
                    .collect(java.util.stream.Collectors.toList());
        }

        model.addAttribute("clientes", clientes);
        model.addAttribute("buscarTermino", buscarTermino);
        model.addAttribute("estadoFiltro", estadoFiltro);
        return "clientes";
    }

    @GetMapping("/mensajes")
    public String mensajes(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<Mensaje> mensajes = mensajeService.obtenerTodasLasPlantillas();
        model.addAttribute("mensajes", mensajes);
        return "mensajes";
    }

    @GetMapping("/envios")
    public String envios(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
        List<Mensaje> mensajes = mensajeService.obtenerTodasLasPlantillas();
        model.addAttribute("clientes", clientes);
        model.addAttribute("mensajes", mensajes);
        return "envios";
    }

    @GetMapping("/historial")
    public String historial(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<MensajeEnviado> historial = envioService.obtenerHistorial();
        model.addAttribute("historial", historial);
        return "historial";
    }

    @GetMapping("/estadisticas")
    public String estadisticas(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Map<String, Object> estadisticas = estadisticaService.obtenerEstadisticasCompletas();
        model.addAttribute("estadisticas", estadisticas);
        return "estadisticas";
    }

    

    @PostMapping("/clientes/guardar")
    public String guardarCliente(@ModelAttribute Cliente cliente, 
                                RedirectAttributes redirectAttributes,
                                HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }
        
        try {
            // Asegurar que el estado no sea null
            if (cliente.getEstado() == null || cliente.getEstado().trim().isEmpty()) {
                cliente.setEstado("activo");
            }
            
            if (cliente.getId() == 0) {
                // Es un cliente nuevo
                cliente.setFechaRegistro(java.time.LocalDateTime.now());
                clienteService.agregarCliente(cliente);
                redirectAttributes.addFlashAttribute("success", "Cliente guardado exitosamente");
            } else {
                // Es una actualización - preservar fecha de registro
                Cliente clienteExistente = clienteService.obtenerClientePorId(cliente.getId());
                if (clienteExistente != null) {
                    cliente.setFechaRegistro(clienteExistente.getFechaRegistro());
                }
                clienteService.actualizarCliente(cliente);
                redirectAttributes.addFlashAttribute("success", "Cliente actualizado exitosamente");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al guardar cliente: " + e.getMessage());
            e.printStackTrace();
        }
        return "redirect:/clientes";
    }

    @GetMapping("/clientes/editar/{id}")
    public String editarCliente(@PathVariable int id, Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }
        
        Cliente cliente = clienteService.obtenerClientePorId(id);
        if (cliente == null) {
            return "redirect:/clientes?error=Cliente no encontrado";
        }
        
        model.addAttribute("cliente", cliente);
        return "cliente-form";
    }

    @GetMapping("/clientes/nuevo")
    public String nuevoCliente(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }
        model.addAttribute("cliente", new Cliente());
        return "cliente-form";
    }

    @GetMapping("/mensaje/nuevo")
    public String nuevoMensaje(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }
        model.addAttribute("mensaje", new Mensaje());
        return "mensaje-form";
    }

    @PostMapping("/mensaje/guardar")
    public String guardarMensaje(@ModelAttribute Mensaje mensaje,
                                RedirectAttributes redirectAttributes,
                                HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }
        
        try {
            mensajeService.crearPlantilla(mensaje);
            redirectAttributes.addFlashAttribute("success", "Plantilla guardada exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al guardar plantilla: " + e.getMessage());
        }
        return "redirect:/mensajes";
    }

    @PostMapping("/envio/individual")
    @ResponseBody
    public Map<String, Object> enviarIndividual(@RequestParam int clienteId, 
                                               @RequestParam int mensajeId,
                                               HttpSession session) {
        Map<String, Object> response = new HashMap<>();
        
        if (session.getAttribute("usuario") == null) {
            response.put("success", false);
            response.put("message", "Sesión expirada");
            return response;
        }
        
        try {
            envioService.enviarMensajeIndividual(clienteId, mensajeId);
            response.put("success", true);
            response.put("message", "Mensaje enviado exitosamente por email");
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error al enviar mensaje: " + e.getMessage());
        }
        
        return response;
    }

    @PostMapping("/envio/masivo")
    @ResponseBody
    public Map<String, Object> enviarMasivo(@RequestParam int mensajeId,
                                           HttpSession session) {
        Map<String, Object> response = new HashMap<>();
        
        if (session.getAttribute("usuario") == null) {
            response.put("success", false);
            response.put("message", "Sesión expirada");
            return response;
        }
        
        try {
            Map<String, Integer> resultado = envioService.enviarMensajeMasivo(mensajeId);
            response.put("success", true);
            response.put("message", "Envío masivo completado por email");
            response.put("resultado", resultado);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error en envío masivo: " + e.getMessage());
        }
        
        return response;
    }

    @GetMapping("/fechas-conmemorativas")
    public String fechasConmemorativas(HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }
        return "redirect:/mensajes";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
