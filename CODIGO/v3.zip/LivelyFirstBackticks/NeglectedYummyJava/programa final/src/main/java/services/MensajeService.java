package services;

import models.Mensaje;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class MensajeService {
    private final String CSV_FILE = "datos/mensajes/plantilla_mensajes.csv";
    private List<Mensaje> plantillas = new ArrayList<>();
    private int nextId = 1;

    public MensajeService() {
        crearDirectorioSiNoExiste();
        cargarPlantillasDesdeCSV();
    }

    private void crearDirectorioSiNoExiste() {
        try {
            Files.createDirectories(Paths.get("datos/mensajes"));
        } catch (Exception e) {
            System.err.println("Error creando directorio: " + e.getMessage());
        }
    }

    public void cargarPlantillasDesdeCSV() {
        try {
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                crearArchivoCSVVacio();
                return;
            }

            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line = reader.readLine(); // Saltar encabezado
                while ((line = reader.readLine()) != null) {
                    if (!line.trim().isEmpty()) {
                        try {
                            String[] parts = parsearLineaCSV(line);
                            if (parts.length >= 5) {
                                Mensaje mensaje = new Mensaje();
                                mensaje.setId(Integer.parseInt(parts[0]));
                                mensaje.setNombre(parts[1]);
                                mensaje.setContenido(parts[2]);
                                mensaje.setTipo(parts[3]);

                                // Manejar asunto (puede estar en posición 4 o 5 dependiendo del formato)
                                if (parts.length >= 6) {
                                    mensaje.setAsunto(parts[4]);
                                    mensaje.setFechaCreacion(LocalDateTime.parse(parts[5], DateTimeFormatter.ISO_LOCAL_DATE_TIME));
                                } else {
                                    mensaje.setAsunto("");
                                    mensaje.setFechaCreacion(LocalDateTime.parse(parts[4], DateTimeFormatter.ISO_LOCAL_DATE_TIME));
                                }

                                plantillas.add(mensaje);
                                nextId = Math.max(nextId, mensaje.getId() + 1);
                            }
                        } catch (Exception e) {
                            System.err.println("Error procesando línea: " + line + " - " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error cargando plantillas: " + e.getMessage());
        }
    }

    private void crearArchivoCSVVacio() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(CSV_FILE))) {
            writer.println("id,nombre,contenido,tipo,fechaCreacion");
        } catch (Exception e) {
            System.err.println("Error creando archivo CSV: " + e.getMessage());
        }
    }

    public void guardarPlantillasEnCSV() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(CSV_FILE))) {
            writer.println("id,nombre,contenido,tipo,fechaCreacion");
            for (Mensaje mensaje : plantillas) {
                writer.printf("%d,\"%s\",\"%s\",\"%s\",%s%n",
                    mensaje.getId(),
                    mensaje.getNombre(),
                    mensaje.getContenido(),
                    mensaje.getTipo(),
                    mensaje.getFechaCreacion().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                );
            }
        } catch (Exception e) {
            System.err.println("Error guardando plantillas: " + e.getMessage());
        }
    }

    public void crearPlantilla(Mensaje mensaje) {
        mensaje.setId(nextId++);
        mensaje.setFechaCreacion(LocalDateTime.now());
        plantillas.add(mensaje);
        guardarPlantillasEnCSV();
    }

    public List<Mensaje> obtenerTodasLasPlantillas() {
        return new ArrayList<>(plantillas);
    }

    public Mensaje obtenerMensajePorId(int id) {
        return plantillas.stream()
                .filter(mensaje -> mensaje.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public Mensaje obtenerPlantillaPorId(int id) {
        return plantillas.stream()
                .filter(m -> m.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void actualizarPlantilla(Mensaje mensaje) {
        for (int i = 0; i < plantillas.size(); i++) {
            if (plantillas.get(i).getId() == mensaje.getId()) {
                plantillas.set(i, mensaje);
                guardarPlantillasEnCSV();
                break;
            }
        }
    }

    public void eliminarPlantilla(int id) {
        plantillas.removeIf(m -> m.getId() == id);
        guardarPlantillasEnCSV();
    }

    public void editarPlantilla(int id, Mensaje mensajeActualizado) {
        for (int i = 0; i < plantillas.size(); i++) {
            if (plantillas.get(i).getId() == id) {
                mensajeActualizado.setId(id);
                mensajeActualizado.setFechaCreacion(plantillas.get(i).getFechaCreacion());
                plantillas.set(i, mensajeActualizado);
                guardarPlantillasEnCSV();
                break;
            }
        }
    }
    // Método para parsear la línea CSV
    private String[] parsearLineaCSV(String line) {
        List<String> parts = new ArrayList<>();
        boolean inQuotes = false;
        StringBuilder currentPart = new StringBuilder();

        for (char c : line.toCharArray()) {
            switch (c) {
                case '\"':
                    inQuotes = !inQuotes;
                    break;
                case ',':
                    if (!inQuotes) {
                        parts.add(currentPart.toString());
                        currentPart = new StringBuilder();
                        break;
                    }
                default:
                    currentPart.append(c);
            }
        }
        parts.add(currentPart.toString());
        return parts.toArray(new String[0]);
    }
}