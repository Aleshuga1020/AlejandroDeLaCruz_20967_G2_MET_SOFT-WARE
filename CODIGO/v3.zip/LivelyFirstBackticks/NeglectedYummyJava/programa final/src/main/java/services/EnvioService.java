package services;

import models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.opencsv.*;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class EnvioService {
    private final String CSV_FILE = "historial.csv";
    private List<MensajeEnviado> historial = new ArrayList<>();

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private MensajeService mensajeService;
    
    @Autowired
    private EmailService emailService;

    public EnvioService() {
        crearDirectorioSiNoExiste();
        cargarHistorialDesdeCSV();
    }

    private void crearDirectorioSiNoExiste() {
        try {
            Files.createDirectories(Paths.get("datos/historial"));
        } catch (Exception e) {
            System.err.println("Error creando directorio: " + e.getMessage());
        }
    }

    public void cargarHistorialDesdeCSV() {
        try {
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                crearArchivoCSVVacio();
                return;
            }

            historial.clear();

            try (CSVReader reader = new CSVReader(new FileReader(file))) {
                List<String[]> records = reader.readAll();
                for (int i = (records.size() > 0 && records.get(0)[0].equals("ID_Cliente")) ? 1 : 0; i < records.size(); i++) {
                    String[] record = records.get(i);
                    if (record.length >= 4 && !record[0].trim().isEmpty()) {
                        try {
                            MensajeEnviado envio = new MensajeEnviado();
                            envio.setClienteId(Integer.parseInt(record[0].trim()));
                            envio.setMensajeId(Integer.parseInt(record[1].trim()));

                            String fechaStr = record[2].trim();
                            if (!fechaStr.isEmpty()) {
                                try {
                                    envio.setFechaEnvio(LocalDateTime.parse(fechaStr, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                                } catch (Exception e) {
                                    try {
                                        envio.setFechaEnvio(LocalDateTime.parse(fechaStr, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
                                    } catch (Exception ex) {
                                        envio.setFechaEnvio(LocalDateTime.now());
                                    }
                                }
                            } else {
                                envio.setFechaEnvio(LocalDateTime.now());
                            }

                            envio.setEstado(record[3].trim());
                            if (record.length >= 5) {
                                envio.setCanal(record[4].trim());
                            } else {
                                envio.setCanal("SMS");
                            }

                            historial.add(envio);
                        } catch (NumberFormatException e) {
                            System.err.println("Error al convertir número en línea: " + Arrays.toString(record));
                        } catch (Exception e) {
                            System.err.println("Error procesando registro: " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error cargando historial: " + e.getMessage());
        }
    }

    private void crearArchivoCSVVacio() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID_Cliente", "ID_Mensaje", "Fecha_Envio", "Estado_Envio", "Canal", "Observaciones"};
            writer.writeNext(header);
        } catch (Exception e) {
            System.err.println("Error creando archivo CSV: " + e.getMessage());
        }
    }

    public void guardarHistorialEnCSV() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID_Cliente", "ID_Mensaje", "Fecha_Envio", "Estado_Envio", "Canal", "Observaciones"};
            writer.writeNext(header);

            for (MensajeEnviado envio : historial) {
                String[] record = {
                    String.valueOf(envio.getClienteId()),
                    String.valueOf(envio.getMensajeId()),
                    envio.getFechaEnvio().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                    envio.getEstado(),
                    envio.getCanal() != null ? envio.getCanal() : "SMS",
                    "enviado".equals(envio.getEstado()) ? "Enviado correctamente" : "Error en el envío"
                };
                writer.writeNext(record);
            }
        } catch (Exception e) {
            System.err.println("Error guardando historial: " + e.getMessage());
        }
    }

    public void enviarMensajeIndividual(int clienteId, int mensajeId) {
        try {
            Cliente cliente = clienteService.obtenerClientePorId(clienteId);
            Mensaje mensaje = mensajeService.obtenerPlantillaPorId(mensajeId);

            if (cliente == null) {
                throw new IllegalArgumentException("Cliente con ID " + clienteId + " no encontrado");
            }

            if (!"activo".equals(cliente.getEstado())) {
                throw new IllegalArgumentException("El cliente no está activo");
            }

            if (mensaje == null) {
                throw new IllegalArgumentException("Plantilla con ID " + mensajeId + " no encontrada");
            }

            // Enviar email real
            String estado;
            try {
                emailService.enviarEmail(cliente.getEmail(), mensaje.getAsunto(), mensaje.getContenido());
                estado = "enviado";
            } catch (Exception e) {
                estado = "fallido";
                System.err.println("Error enviando email: " + e.getMessage());
            }

            MensajeEnviado envio = new MensajeEnviado(clienteId, mensajeId, estado, "Email");
            historial.add(envio);
            
            // Guardar inmediatamente y forzar sincronización
            guardarHistorialEnCSV();
            
            // Forzar recarga del historial desde el archivo
            cargarHistorialDesdeCSV();
            
            System.out.println("Mensaje individual enviado - Historial actualizado. Total registros: " + historial.size());
        } catch (Exception e) {
            System.err.println("Error en envío individual: " + e.getMessage());
            throw new RuntimeException("Error al enviar mensaje: " + e.getMessage());
        }
    }

    public Map<String, Integer> enviarMensajeMasivo(int mensajeId) {
        try {
            List<Cliente> clientesActivos = clienteService.obtenerClientesActivos();
            Mensaje mensaje = mensajeService.obtenerPlantillaPorId(mensajeId);

            if (mensaje == null) {
                throw new IllegalArgumentException("Plantilla no encontrada");
            }

            if (clientesActivos.isEmpty()) {
                throw new IllegalArgumentException("No hay clientes activos");
            }

            int exitosos = 0;
            int fallidos = 0;

            for (Cliente cliente : clientesActivos) {
                String estado;
                try {
                    emailService.enviarEmail(cliente.getEmail(), mensaje.getAsunto(), mensaje.getContenido());
                    estado = "enviado";
                    exitosos++;
                } catch (Exception e) {
                    estado = "fallido";
                    fallidos++;
                    System.err.println("Error enviando email a " + cliente.getEmail() + ": " + e.getMessage());
                }

                MensajeEnviado envio = new MensajeEnviado(cliente.getId(), mensajeId, estado, "Email");
                historial.add(envio);
            }

            // Guardar inmediatamente y forzar sincronización
            guardarHistorialEnCSV();
            
            // Forzar recarga del historial desde el archivo
            cargarHistorialDesdeCSV();
            
            System.out.println("Envío masivo completado - Historial actualizado. Total registros: " + historial.size());

            Map<String, Integer> resultado = new HashMap<>();
            resultado.put("exitosos", exitosos);
            resultado.put("fallidos", fallidos);
            resultado.put("total", clientesActivos.size());

            return resultado;
        } catch (Exception e) {
            System.err.println("Error en envío masivo: " + e.getMessage());
            throw new RuntimeException("Error al enviar mensajes masivos: " + e.getMessage());
        }
    }

    public List<MensajeEnviado> obtenerHistorial() {
        try {
            // Siempre recargar desde CSV para garantizar datos actualizados
            cargarHistorialDesdeCSV();
            List<MensajeEnviado> historialEnriquecido = new ArrayList<>();

            if (historial == null || historial.isEmpty()) {
                System.out.println("Historial vacío o nulo");
                return historialEnriquecido;
            }
            
            System.out.println("Cargando historial con " + historial.size() + " registros");

            for (MensajeEnviado envio : historial) {
                if (envio == null) continue;

                MensajeEnviado envioEnriquecido = new MensajeEnviado();
                envioEnriquecido.setClienteId(envio.getClienteId());
                envioEnriquecido.setMensajeId(envio.getMensajeId());
                envioEnriquecido.setEstado(envio.getEstado() != null ? envio.getEstado() : "desconocido");
                envioEnriquecido.setCanal(envio.getCanal() != null ? envio.getCanal() : "SMS");
                envioEnriquecido.setFechaEnvio(envio.getFechaEnvio() != null ? envio.getFechaEnvio() : LocalDateTime.now());

                try {
                    if (clienteService != null) {
                        Cliente cliente = clienteService.obtenerClientePorId(envio.getClienteId());
                        if (cliente != null && cliente.getNombre() != null) {
                            envioEnriquecido.setNombreCliente(cliente.getNombre());
                        } else {
                            envioEnriquecido.setNombreCliente("Cliente no encontrado (ID: " + envio.getClienteId() + ")");
                        }
                    } else {
                        envioEnriquecido.setNombreCliente("Servicio no disponible");
                    }
                } catch (Exception e) {
                    envioEnriquecido.setNombreCliente("Error al cargar cliente (ID: " + envio.getClienteId() + ")");
                }

                try {
                    if (mensajeService != null) {
                        Mensaje mensaje = mensajeService.obtenerPlantillaPorId(envio.getMensajeId());
                        if (mensaje != null && mensaje.getNombre() != null) {
                            envioEnriquecido.setNombreMensaje(mensaje.getNombre());
                        } else {
                            envioEnriquecido.setNombreMensaje("Mensaje no encontrado (ID: " + envio.getMensajeId() + ")");
                        }
                    } else {
                        envioEnriquecido.setNombreMensaje("Servicio no disponible");
                    }
                } catch (Exception e) {
                    envioEnriquecido.setNombreMensaje("Error al cargar mensaje (ID: " + envio.getMensajeId() + ")");
                }

                historialEnriquecido.add(envioEnriquecido);
            }

            return historialEnriquecido;
        } catch (Exception e) {
            System.err.println("Error general al obtener historial: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}