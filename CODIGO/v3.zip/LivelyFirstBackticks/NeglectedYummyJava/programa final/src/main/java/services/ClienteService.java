package services;

import models.Cliente;
import org.springframework.stereotype.Service;
import com.opencsv.*;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class ClienteService {
    private final String CSV_FILE = "clientes.csv";
    private List<Cliente> clientes = new ArrayList<>();
    private AtomicInteger proximoId = new AtomicInteger(1);

    public ClienteService() {
        crearDirectorioSiNoExiste();
        cargarClientesDesdeCSV();
    }

    private void crearDirectorioSiNoExiste() {
        try {
            Files.createDirectories(Paths.get("datos/clientes"));
        } catch (Exception e) {
            System.err.println("Error creando directorio: " + e.getMessage());
        }
    }

    public void cargarClientesDesdeCSV() {
        try {
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                crearArchivoCSVVacio();
                return;
            }

            try (CSVReader reader = new CSVReader(new FileReader(file))) {
                List<String[]> records = reader.readAll();
                // Skip header row if it exists
                boolean hasHeader = records.size() > 0 && 
                    (records.get(0)[0].equalsIgnoreCase("id") || 
                     records.get(0)[0].equalsIgnoreCase("ID"));
                
                for (int i = hasHeader ? 1 : 0; i < records.size(); i++) {
                    String[] record = records.get(i);
                    if (record.length >= 6 && !record[0].trim().isEmpty()) {
                        try {
                            Cliente cliente = new Cliente();
                            cliente.setId(Integer.parseInt(record[0].trim()));
                            cliente.setNombre(record[1].trim());
                            cliente.setCedula(record[2].trim());
                            cliente.setTelefono(record[3].trim());
                            cliente.setEmail(record[4].trim());
                            cliente.setEstado(record[5].trim());
                            
                            // Set fecha de registro if available
                            if (record.length > 6 && !record[6].trim().isEmpty()) {
                                try {
                                    cliente.setFechaRegistro(LocalDateTime.parse(record[6].trim(), 
                                        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                                } catch (Exception e) {
                                    cliente.setFechaRegistro(LocalDateTime.now());
                                }
                            } else {
                                cliente.setFechaRegistro(LocalDateTime.now());
                            }
                            
                            clientes.add(cliente);
                            if (cliente.getId() >= proximoId.get()) {
                                proximoId.set(cliente.getId() + 1);
                            }
                        } catch (NumberFormatException e) {
                            System.err.println("Error procesando cliente en línea " + (i+1) + ": " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error cargando clientes: " + e.getMessage());
        }
    }

    private void crearArchivoCSVVacio() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID", "Nombre", "Cedula", "Telefono", "Email", "Estado", "Fecha_Registro"};
            writer.writeNext(header);
        } catch (Exception e) {
            System.err.println("Error creating archivo CSV: " + e.getMessage());
        }
    }

    public void guardarClientesEnCSV() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID", "Nombre", "Cedula", "Telefono", "Email", "Estado", "Fecha_Registro"};
            writer.writeNext(header);

            for (Cliente cliente : clientes) {
                String[] record = {
                    String.valueOf(cliente.getId()),
                    cliente.getNombre(),
                    cliente.getCedula(),
                    cliente.getTelefono(),
                    cliente.getEmail(),
                    cliente.getEstado(),
                    (cliente.getFechaRegistro() != null) ? cliente.getFechaRegistro().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) : null
                };
                writer.writeNext(record);
            }
        } catch (Exception e) {
            System.err.println("Error guardando clientes: " + e.getMessage());
        }
    }

    public void agregarCliente(Cliente cliente) {
        if (!validarTelefono(cliente.getTelefono())) {
            throw new IllegalArgumentException("El teléfono debe tener exactamente 10 dígitos");
        }
        if (!validarCedulaEcuatoriana(cliente.getCedula())) {
            throw new IllegalArgumentException("La cédula ecuatoriana no es válida");
        }
        
        // Validar que la cédula no esté duplicada
        if (existeCedula(cliente.getCedula())) {
            throw new IllegalArgumentException("Ya existe un cliente con esta cédula");
        }
        
        // Validar que el teléfono no esté duplicado
        if (existeTelefono(cliente.getTelefono())) {
            throw new IllegalArgumentException("Ya existe un cliente con este teléfono");
        }
        
        // Validar que el email no esté duplicado
        if (existeEmail(cliente.getEmail())) {
            throw new IllegalArgumentException("Ya existe un cliente con este email");
        }
        
        cliente.setId(proximoId.getAndIncrement());
        cliente.setFechaRegistro(LocalDateTime.now());
        clientes.add(cliente);
        guardarClientesEnCSV();
    }

    public void actualizarCliente(Cliente clienteActualizado) {
        if (!validarTelefono(clienteActualizado.getTelefono())) {
            throw new IllegalArgumentException("El teléfono debe tener exactamente 10 dígitos");
        }
        if (!validarCedulaEcuatoriana(clienteActualizado.getCedula())) {
            throw new IllegalArgumentException("La cédula ecuatoriana no es válida");
        }
        
        // Validar que la cédula no esté duplicada (excepto para el mismo cliente)
        if (existeCedulaExceptoId(clienteActualizado.getCedula(), clienteActualizado.getId())) {
            throw new IllegalArgumentException("Ya existe otro cliente con esta cédula");
        }
        
        // Validar que el teléfono no esté duplicado (excepto para el mismo cliente)
        if (existeTelefonoExceptoId(clienteActualizado.getTelefono(), clienteActualizado.getId())) {
            throw new IllegalArgumentException("Ya existe otro cliente con este teléfono");
        }
        
        // Validar que el email no esté duplicado (excepto para el mismo cliente)
        if (existeEmailExceptoId(clienteActualizado.getEmail(), clienteActualizado.getId())) {
            throw new IllegalArgumentException("Ya existe otro cliente con este email");
        }

        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getId() == clienteActualizado.getId()) {
                clientes.set(i, clienteActualizado);
                guardarClientesEnCSV();
                return;
            }
        }
        throw new IllegalArgumentException("Cliente no encontrado");
    }

    private boolean validarTelefono(String telefono) {
        return telefono != null && telefono.matches("\\d{10}");
    }

    public boolean validarCedulaEcuatoriana(String cedula) {
        if (cedula == null || cedula.length() != 10) {
            return false;
        }

        // Verificar que todos los caracteres sean dígitos
        if (!cedula.matches("\\d{10}")) {
            return false;
        }

        // Verificar que los dos primeros dígitos correspondan a una provincia válida (01-24)
        int provincia = Integer.parseInt(cedula.substring(0, 2));
        if (provincia < 1 || provincia > 24) {
            return false;
        }

        // Aplicar algoritmo módulo 10
        int[] coeficientes = {2, 1, 2, 1, 2, 1, 2, 1, 2};
        int suma = 0;

        for (int i = 0; i < 9; i++) {
            int valor = Integer.parseInt(String.valueOf(cedula.charAt(i))) * coeficientes[i];
            if (valor >= 10) {
                valor = valor - 9;
            }
            suma += valor;
        }

        int residuo = suma % 10;
        int digitoVerificador = residuo == 0 ? 0 : 10 - residuo;
        int ultimoDigito = Integer.parseInt(String.valueOf(cedula.charAt(9)));

        return digitoVerificador == ultimoDigito;
    }

    public List<Cliente> obtenerTodosLosClientes() {
        return new ArrayList<>(clientes);
    }

    public List<Cliente> obtenerClientesActivos() {
        List<Cliente> clientesActivos = clientes.stream()
                .filter(c -> c.getEstado() != null && c.getEstado().equalsIgnoreCase("activo"))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
        
        System.out.println("Clientes activos encontrados: " + clientesActivos.size());
        for (Cliente cliente : clientesActivos) {
            System.out.println("Cliente: " + cliente.getNombre() + " - Estado: " + cliente.getEstado());
        }
        
        return clientesActivos;
    }

    public Cliente obtenerClientePorId(int id) {
        return clientes.stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<Cliente> buscarClientes(String termino) {
        if (termino == null || termino.trim().isEmpty()) {
            return obtenerTodosLosClientes();
        }

        String terminoLower = termino.toLowerCase().trim();
        return clientes.stream()
                .filter(c -> 
                    c.getNombre().toLowerCase().contains(terminoLower) ||
                    c.getCedula().contains(terminoLower) ||
                    c.getTelefono().contains(terminoLower) ||
                    c.getEmail().toLowerCase().contains(terminoLower)
                )
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public List<Cliente> filtrarClientesPorEstado(String estado) {
        if (estado == null || estado.trim().isEmpty()) {
            return obtenerTodosLosClientes();
        }

        return clientes.stream()
                .filter(c -> c.getEstado().equalsIgnoreCase(estado.trim()))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public void eliminarCliente(int id) {
        clientes.removeIf(c -> c.getId() == id);
        guardarClientesEnCSV();
    }
    
    // Métodos para validar duplicados
    private boolean existeCedula(String cedula) {
        return clientes.stream().anyMatch(c -> c.getCedula().equals(cedula));
    }
    
    private boolean existeTelefono(String telefono) {
        return clientes.stream().anyMatch(c -> c.getTelefono().equals(telefono));
    }
    
    private boolean existeEmail(String email) {
        return clientes.stream().anyMatch(c -> c.getEmail().equals(email));
    }
    
    private boolean existeCedulaExceptoId(String cedula, int idExcluir) {
        return clientes.stream().anyMatch(c -> c.getCedula().equals(cedula) && c.getId() != idExcluir);
    }
    
    private boolean existeTelefonoExceptoId(String telefono, int idExcluir) {
        return clientes.stream().anyMatch(c -> c.getTelefono().equals(telefono) && c.getId() != idExcluir);
    }
    
    private boolean existeEmailExceptoId(String email, int idExcluir) {
        return clientes.stream().anyMatch(c -> c.getEmail().equals(email) && c.getId() != idExcluir);
    }
}