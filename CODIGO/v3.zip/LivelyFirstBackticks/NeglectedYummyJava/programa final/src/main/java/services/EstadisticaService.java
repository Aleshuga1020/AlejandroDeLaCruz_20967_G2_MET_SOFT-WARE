
package services;

import models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EstadisticaService {

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private EnvioService envioService;

    @Autowired
    private MensajeService mensajeService;

    public Map<String, Object> obtenerEstadisticasGenerales() {
        Map<String, Object> estadisticas = new HashMap<>();
        
        List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
        List<MensajeEnviado> historial = envioService.obtenerHistorial();
        
        // Estadísticas básicas
        estadisticas.put("totalClientes", clientes.size());
        estadisticas.put("clientesActivos", clientes.stream()
                .mapToInt(c -> "activo".equalsIgnoreCase(c.getEstado()) ? 1 : 0)
                .sum());
        estadisticas.put("totalMensajes", historial.size());
        estadisticas.put("totalPlantillas", mensajeService.obtenerTodasLasPlantillas().size());
        
        // Tasa de éxito
        long mensajesExitosos = historial.stream()
                .mapToLong(m -> "enviado".equalsIgnoreCase(m.getEstado()) ? 1 : 0)
                .sum();
        
        double tasaExito = historial.size() > 0 ? 
                (double) mensajesExitosos / historial.size() * 100 : 0;
        estadisticas.put("tasaExito", Math.round(tasaExito * 100.0) / 100.0);
        
        return estadisticas;
    }

    public Map<String, Object> obtenerEstadisticasCompletas() {
        Map<String, Object> estadisticas = obtenerEstadisticasGenerales();
        
        List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
        List<MensajeEnviado> historial = envioService.obtenerHistorial();
        
        // Estadísticas por canal (solo email)
        Map<String, Long> enviosPorCanal = new HashMap<>();
        enviosPorCanal.put("Email", (long) historial.size());
        estadisticas.put("enviosPorCanal", enviosPorCanal);
        
        // Dominios de email más comunes
        Map<String, Long> dominiosEmail = new HashMap<>();
        clientes.forEach(c -> {
            if (c.getEmail() != null && c.getEmail().contains("@")) {
                String dominio = c.getEmail().substring(c.getEmail().indexOf("@") + 1);
                dominiosEmail.put(dominio, dominiosEmail.getOrDefault(dominio, 0L) + 1);
            }
        });
        estadisticas.put("dominiosComunes", dominiosEmail);
        
        // Mensajes hoy
        long mensajesHoy = historial.stream()
                .filter(m -> m.getFechaEnvio().toLocalDate().equals(java.time.LocalDate.now()))
                .count();
        estadisticas.put("mensajesHoy", mensajesHoy);
        
        // Mensajes por estado
        Map<String, Long> enviosPorEstado = new HashMap<>();
        historial.forEach(m -> {
            String estado = m.getEstado() != null ? m.getEstado() : "No especificado";
            enviosPorEstado.put(estado, enviosPorEstado.getOrDefault(estado, 0L) + 1);
        });
        estadisticas.put("enviosPorEstado", enviosPorEstado);
        
        return estadisticas;
    }
}
