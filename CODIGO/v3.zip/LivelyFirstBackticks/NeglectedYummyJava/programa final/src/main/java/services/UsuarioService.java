package services;

import models.Usuario;
import org.springframework.stereotype.Service;
import com.opencsv.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class UsuarioService {
    private static final String CSV_FILE = "usuarios.csv";
    private static final String EXCEL_FILE = "usuarios.xlsx";
    private final List<Usuario> usuarios = new ArrayList<>();
    private final AtomicInteger proximoId = new AtomicInteger(1);

    public UsuarioService() {
        crearArchivoCSVSiNoExiste();
        cargarUsuariosDesdeCSV();
        crearUsuarioAdminPorDefecto();
    }

    private void crearArchivoCSVSiNoExiste() {
        File file = new File(CSV_FILE);
        if (!file.exists()) {
            crearArchivoCSVVacio();
        }
    }

    private void crearArchivoCSVVacio() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID", "Username", "Password", "Email", "Rol", "CodigoAdmin", "FechaCreacion", "Activo"};
            writer.writeNext(header);
        } catch (Exception e) {
            System.err.println("Error creando archivo CSV de usuarios: " + e.getMessage());
        }
    }

    private void cargarUsuariosDesdeCSV() {
        File file = new File(CSV_FILE);
        if (!file.exists()) return;

        try (CSVReader reader = new CSVReader(new FileReader(file))) {
            List<String[]> records = reader.readAll();
            if (records.size() > 1) {
                for (int i = 1; i < records.size(); i++) {
                    String[] record = records.get(i);
                    if (record.length >= 8 && !record[0].trim().isEmpty()) {
                        try {
                            Usuario usuario = new Usuario();
                            usuario.setId(Integer.parseInt(record[0].trim()));
                            usuario.setUsername(record[1].trim());
                            usuario.setPassword(record[2].trim());
                            usuario.setEmail(record[3].trim());
                            usuario.setRol(record[4].trim());
                            usuario.setCodigoAdmin(record[5].trim());

                            if (!record[6].trim().isEmpty()) {
                                try {
                                    usuario.setFechaCreacion(LocalDateTime.parse(record[6].trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                                } catch (Exception e) {
                                    usuario.setFechaCreacion(LocalDateTime.now());
                                }
                            } else {
                                usuario.setFechaCreacion(LocalDateTime.now());
                            }

                            usuario.setActivo(Boolean.parseBoolean(record[7].trim()));
                            usuarios.add(usuario);

                            if (usuario.getId() >= proximoId.get()) {
                                proximoId.set(usuario.getId() + 1);
                            }
                        } catch (Exception e) {
                            System.err.println("Error procesando usuario en línea " + (i+1) + ": " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error cargando usuarios: " + e.getMessage());
        }
    }

    private void crearUsuarioAdminPorDefecto() {
        boolean adminExiste = usuarios.stream()
            .anyMatch(u -> u.getUsername().equals("administrador"));

        if (!adminExiste) {
            Usuario admin = new Usuario("administrador", "administrador001", "admin@sistema.com", "ADMIN", "ADMIN123");
            admin.setId(proximoId.getAndIncrement());
            usuarios.add(admin);
            guardarUsuariosEnCSV();
            exportarUsuariosAExcel();
        }
    }

    public void guardarUsuariosEnCSV() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID", "Username", "Password", "Email", "Rol", "CodigoAdmin", "FechaCreacion", "Activo"};
            writer.writeNext(header);

            for (Usuario usuario : usuarios) {
                String[] record = {
                    String.valueOf(usuario.getId()),
                    usuario.getUsername(),
                    usuario.getPassword(),
                    usuario.getEmail(),
                    usuario.getRol(),
                    usuario.getCodigoAdmin(),
                    usuario.getFechaCreacion().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                    String.valueOf(usuario.isActivo())
                };
                writer.writeNext(record);
            }
        } catch (Exception e) {
            System.err.println("Error guardando usuarios: " + e.getMessage());
        }
    }

    public void exportarUsuariosAExcel() {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Usuarios");

            // Crear encabezados
            Row headerRow = sheet.createRow(0);
            String[] headers = {"ID", "Username", "Password", "Email", "Rol", "CodigoAdmin", "FechaCreacion", "Activo"};
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
            }

            // Llenar datos
            int rowNum = 1;
            for (Usuario usuario : usuarios) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(usuario.getId());
                row.createCell(1).setCellValue(usuario.getUsername());
                row.createCell(2).setCellValue(usuario.getPassword());
                row.createCell(3).setCellValue(usuario.getEmail());
                row.createCell(4).setCellValue(usuario.getRol());
                row.createCell(5).setCellValue(usuario.getCodigoAdmin());
                row.createCell(6).setCellValue(usuario.getFechaCreacion().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                row.createCell(7).setCellValue(usuario.isActivo());
            }

            // Autoajustar columnas
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            try (FileOutputStream fileOut = new FileOutputStream(EXCEL_FILE)) {
                workbook.write(fileOut);
            }
        } catch (Exception e) {
            System.err.println("Error exportando usuarios a Excel: " + e.getMessage());
        }
    }

    public Usuario autenticarUsuario(String username, String password) {
        return usuarios.stream()
            .filter(u -> u.getUsername().equals(username) && u.getPassword().equals(password) && u.isActivo())
            .findFirst()
            .orElse(null);
    }

    public Usuario validarCredenciales(String username, String password) {
        return autenticarUsuario(username, password);
    }

    public boolean recuperarContrasena(String username, String codigoAdmin, String nuevaContrasena) {
        try {
            // Verificar código de administrador
            if (!"ADMIN123".equals(codigoAdmin)) {
                System.out.println("Código de administrador inválido: " + codigoAdmin);
                return false;
            }

            // Buscar usuario
            Usuario usuario = null;
            for (Usuario u : usuarios) {
                if (u.getUsername().equals(username)) {
                    usuario = u;
                    break;
                }
            }

            if (usuario == null) {
                System.out.println("Usuario no encontrado: " + username);
                return false;
            }

            // Actualizar contraseña
            usuario.setPassword(nuevaContrasena);
            guardarUsuariosEnCSV();
            System.out.println("Contraseña actualizada exitosamente para: " + username);
            return true;
        } catch (Exception e) {
            System.err.println("Error al recuperar contraseña: " + e.getMessage());
            return false;
        }
    }

    public List<Usuario> obtenerTodosLosUsuarios() {
        return new ArrayList<>(usuarios);
    }

    public Usuario crearUsuario(String username, String password, String email, String rol, String codigoAdmin) {
        // Verificar si el usuario ya existe
        boolean usuarioExiste = usuarios.stream()
            .anyMatch(u -> u.getUsername().equals(username));

        if (usuarioExiste) {
            return null;
        }

        Usuario nuevoUsuario = new Usuario(username, password, email, rol, codigoAdmin);
        nuevoUsuario.setId(proximoId.getAndIncrement());
        usuarios.add(nuevoUsuario);
        guardarUsuariosEnCSV();
        exportarUsuariosAExcel();
        return nuevoUsuario;
    }
}