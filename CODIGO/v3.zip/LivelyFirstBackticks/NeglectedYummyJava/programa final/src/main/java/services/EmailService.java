
package services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void enviarEmail(String destinatario, String asunto, String contenido) {
        try {
            SimpleMailMessage mensaje = new SimpleMailMessage();
            mensaje.setFrom("tu-email-temporal@gmail.com");
            mensaje.setTo(destinatario);
            mensaje.setSubject(asunto);
            mensaje.setText(contenido);
            
            mailSender.send(mensaje);
            System.out.println("Email enviado exitosamente a: " + destinatario);
        } catch (Exception e) {
            System.err.println("Error enviando email a " + destinatario + ": " + e.getMessage());
            throw new RuntimeException("Error al enviar email", e);
        }
    }
}
