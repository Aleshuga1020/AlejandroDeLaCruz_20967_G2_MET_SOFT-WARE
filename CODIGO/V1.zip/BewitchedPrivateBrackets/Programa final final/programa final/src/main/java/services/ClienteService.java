package services;

import models.Cliente;
import org.springframework.stereotype.Service;
import com.opencsv.*;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class ClienteService {
    private final String CSV_FILE = "clientes.csv";
    private List<Cliente> clientes = new ArrayList<>();
    private AtomicInteger proximoId = new AtomicInteger(1);

    public ClienteService() {
        crearDirectorioSiNoExiste();
        cargarClientesDesdeCSV();
    }

    private void crearDirectorioSiNoExiste() {
        try {
            Files.createDirectories(Paths.get("datos/clientes"));
        } catch (Exception e) {
            System.err.println("Error creando directorio: " + e.getMessage());
        }
    }

    public void cargarClientesDesdeCSV() {
        try {
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                crearArchivoCSVVacio();
                return;
            }

            try (CSVReader reader = new CSVReader(new FileReader(file))) {
                List<String[]> records = reader.readAll();
                // Skip header row if it exists
                for (int i = (records.size() > 0 && (records.get(0)[0].equals("id") || records.get(0)[0].equals("ID"))) ? 1 : 0; i < records.size(); i++) {
                    String[] record = records.get(i);
                    if (record.length >= 6 && !record[0].trim().isEmpty() && !record[0].trim().equals("id") && !record[0].trim().equals("ID")) {
                        try {
                            Cliente cliente = new Cliente();
                            cliente.setId(Integer.parseInt(record[0].trim()));
                            cliente.setNombre(record[1].trim());
                            cliente.setCedula(record[2].trim());
                            cliente.setTelefono(record[3].trim());
                            cliente.setEmail(record[4].trim());
                            cliente.setEstado(record[5].trim());
                            clientes.add(cliente);
                            if (cliente.getId() >= proximoId.get()) {
                                proximoId.set(cliente.getId() + 1);
                            }
                        } catch (NumberFormatException e) {
                            System.err.println("Error procesando cliente en línea " + (i+1) + ": " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error cargando clientes: " + e.getMessage());
        }
    }

    private void crearArchivoCSVVacio() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID", "Nombre", "Cedula", "Telefono", "Email", "Estado", "Fecha_Registro"};
            writer.writeNext(header);
        } catch (Exception e) {
            System.err.println("Error creating archivo CSV: " + e.getMessage());
        }
    }

    public void guardarClientesEnCSV() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID", "Nombre", "Cedula", "Telefono", "Email", "Estado", "Fecha_Registro"};
            writer.writeNext(header);

            for (Cliente cliente : clientes) {
                String[] record = {
                    String.valueOf(cliente.getId()),
                    cliente.getNombre(),
                    cliente.getCedula(),
                    cliente.getTelefono(),
                    cliente.getEmail(),
                    cliente.getEstado(),
                    (cliente.getFechaRegistro() != null) ? cliente.getFechaRegistro().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) : null
                };
                writer.writeNext(record);
            }
        } catch (Exception e) {
            System.err.println("Error guardando clientes: " + e.getMessage());
        }
    }

    public void agregarCliente(Cliente cliente) {
        if (!validarTelefono(cliente.getTelefono())) {
            throw new IllegalArgumentException("El teléfono debe tener exactamente 10 dígitos");
        }
        if (!validarCedulaEcuatoriana(cliente.getCedula())) {
            throw new IllegalArgumentException("La cédula ecuatoriana no es válida");
        }
        cliente.setId(proximoId.getAndIncrement());
        cliente.setFechaRegistro(LocalDateTime.now());
        clientes.add(cliente);
        guardarClientesEnCSV();
    }

    public void actualizarCliente(Cliente clienteActualizado) {
        if (!validarTelefono(clienteActualizado.getTelefono())) {
            throw new IllegalArgumentException("El teléfono debe tener exactamente 10 dígitos");
        }
        if (!validarCedulaEcuatoriana(clienteActualizado.getCedula())) {
            throw new IllegalArgumentException("La cédula ecuatoriana no es válida");
        }

        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getId() == clienteActualizado.getId()) {
                clientes.set(i, clienteActualizado);
                guardarClientesEnCSV();
                return;
            }
        }
        throw new IllegalArgumentException("Cliente no encontrado");
    }

    private boolean validarTelefono(String telefono) {
        return telefono != null && telefono.matches("\\d{10}");
    }

    public boolean validarCedulaEcuatoriana(String cedula) {
        if (cedula == null || cedula.length() != 10) {
            return false;
        }

        // Verificar que todos los caracteres sean dígitos
        if (!cedula.matches("\\d{10}")) {
            return false;
        }

        // Verificar que los dos primeros dígitos correspondan a una provincia válida (01-24)
        int provincia = Integer.parseInt(cedula.substring(0, 2));
        if (provincia < 1 || provincia > 24) {
            return false;
        }

        // Aplicar algoritmo módulo 10
        int[] coeficientes = {2, 1, 2, 1, 2, 1, 2, 1, 2};
        int suma = 0;

        for (int i = 0; i < 9; i++) {
            int valor = Integer.parseInt(String.valueOf(cedula.charAt(i))) * coeficientes[i];
            if (valor >= 10) {
                valor = valor - 9;
            }
            suma += valor;
        }

        int residuo = suma % 10;
        int digitoVerificador = residuo == 0 ? 0 : 10 - residuo;
        int ultimoDigito = Integer.parseInt(String.valueOf(cedula.charAt(9)));

        return digitoVerificador == ultimoDigito;
    }

    public List<Cliente> obtenerTodosLosClientes() {
        return new ArrayList<>(clientes);
    }

    public List<Cliente> obtenerClientesActivos() {
        return clientes.stream()
                .filter(c -> "activo".equals(c.getEstado()))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public Cliente obtenerClientePorId(int id) {
        return clientes.stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<Cliente> buscarClientes(String termino) {
        if (termino == null || termino.trim().isEmpty()) {
            return obtenerTodosLosClientes();
        }

        String terminoLower = termino.toLowerCase().trim();
        return clientes.stream()
                .filter(c -> 
                    c.getNombre().toLowerCase().contains(terminoLower) ||
                    c.getCedula().contains(terminoLower) ||
                    c.getTelefono().contains(terminoLower) ||
                    c.getEmail().toLowerCase().contains(terminoLower)
                )
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public List<Cliente> filtrarClientesPorEstado(String estado) {
        if (estado == null || estado.trim().isEmpty()) {
            return obtenerTodosLosClientes();
        }

        return clientes.stream()
                .filter(c -> c.getEstado().equalsIgnoreCase(estado.trim()))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public void eliminarCliente(int id) {
        clientes.removeIf(c -> c.getId() == id);
        guardarClientesEnCSV();
    }
}