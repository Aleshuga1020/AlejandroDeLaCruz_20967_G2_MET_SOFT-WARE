
package services;

import models.Mensaje;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.MonthDay;
import java.util.*;

@Service
public class FechasConmemorativasService {

    @Autowired
    private MensajeService mensajeService;

    private final Map<MonthDay, String[]> fechasConmemorativas = new HashMap<>();

    public FechasConmemorativasService() {
        inicializarFechasConmemorativas();
    }

    private void inicializarFechasConmemorativas() {
        // Enero
        fechasConmemorativas.put(MonthDay.of(1, 1), new String[]{"Año Nuevo", "¡Feliz Año Nuevo! Te deseamos un próspero año lleno de éxitos y bendiciones."});
        fechasConmemorativas.put(MonthDay.of(1, 6), new String[]{"Día de Reyes", "¡Feliz Día de Reyes! Que la magia de esta fecha llene tu hogar de alegría."});
        
        // Febrero
        fechasConmemorativas.put(MonthDay.of(2, 14), new String[]{"Día de San Valentín", "¡Feliz Día del Amor y la Amistad! Celebra con quienes más quieres."});
        
        // Marzo
        fechasConmemorativas.put(MonthDay.of(3, 8), new String[]{"Día de la Mujer", "¡Feliz Día Internacional de la Mujer! Celebramos tu fuerza y determinación."});
        fechasConmemorativas.put(MonthDay.of(3, 21), new String[]{"Día de la Primavera", "¡Bienvenida Primavera! Que esta nueva estación traiga renovación a tu vida."});
        
        // Abril
        fechasConmemorativas.put(MonthDay.of(4, 23), new String[]{"Día del Libro", "¡Feliz Día del Libro! La lectura abre mundos de posibilidades."});
        
        // Mayo
        fechasConmemorativas.put(MonthDay.of(5, 1), new String[]{"Día del Trabajador", "¡Feliz Día del Trabajador! Reconocemos tu esfuerzo y dedicación."});
        fechasConmemorativas.put(MonthDay.of(5, 10), new String[]{"Día de la Madre", "¡Feliz Día de la Madre! Celebramos a las madres extraordinarias."});
        
        // Junio
        fechasConmemorativas.put(MonthDay.of(6, 21), new String[]{"Día del Padre", "¡Feliz Día del Padre! Honramos a los padres ejemplares."});
        
        // Julio
        fechasConmemorativas.put(MonthDay.of(7, 20), new String[]{"Día del Amigo", "¡Feliz Día del Amigo! Celebra la amistad verdadera."});
        
        // Septiembre
        fechasConmemorativas.put(MonthDay.of(9, 21), new String[]{"Día del Estudiante", "¡Feliz Día del Estudiante! El conocimiento es el mejor regalo."});
        
        // Octubre
        fechasConmemorativas.put(MonthDay.of(10, 31), new String[]{"Halloween", "¡Feliz Halloween! Que tengas una noche llena de diversión."});
        
        // Diciembre
        fechasConmemorativas.put(MonthDay.of(12, 24), new String[]{"Nochebuena", "¡Feliz Nochebuena! Que la paz y el amor llenen tu hogar."});
        fechasConmemorativas.put(MonthDay.of(12, 25), new String[]{"Navidad", "¡Feliz Navidad! Que esta fecha especial traiga felicidad a tu familia."});
        fechasConmemorativas.put(MonthDay.of(12, 31), new String[]{"Fin de Año", "¡Feliz Fin de Año! Te deseamos un próspero Año Nuevo lleno de éxitos."});
    }

    public void crearMensajesConmemorativos() {
        List<Mensaje> plantillasExistentes = mensajeService.obtenerTodasLasPlantillas();
        
        for (Map.Entry<MonthDay, String[]> entrada : fechasConmemorativas.entrySet()) {
            String nombreMensaje = "Conmemorativo - " + entrada.getValue()[0];
            
            // Verificar si ya existe un mensaje con este nombre
            boolean existe = plantillasExistentes.stream()
                    .anyMatch(m -> m.getNombre().equals(nombreMensaje));
            
            if (!existe) {
                Mensaje mensaje = new Mensaje();
                mensaje.setNombre(nombreMensaje);
                mensaje.setContenido(entrada.getValue()[1]);
                mensaje.setTipo("Conmemorativo");
                mensajeService.crearPlantilla(mensaje);
            }
        }
    }

    public List<String[]> obtenerFechasProximas() {
        LocalDate hoy = LocalDate.now();
        List<String[]> fechasProximas = new ArrayList<>();
        
        for (int i = 0; i < 30; i++) { // Próximos 30 días
            LocalDate fecha = hoy.plusDays(i);
            MonthDay monthDay = MonthDay.from(fecha);
            
            if (fechasConmemorativas.containsKey(monthDay)) {
                String[] info = fechasConmemorativas.get(monthDay);
                fechasProximas.add(new String[]{
                    fecha.toString(),
                    info[0],
                    info[1]
                });
            }
        }
        
        return fechasProximas;
    }

    public String[] obtenerMensajeDelDia() {
        MonthDay hoy = MonthDay.from(LocalDate.now());
        return fechasConmemorativas.get(hoy);
    }

    public Map<String, Object> obtenerFechasDelMes() {
        Map<String, Object> resultado = new HashMap<>();
        resultado.put("fechasProximas", obtenerFechasProximas());
        resultado.put("mensajeDelDia", obtenerMensajeDelDia());
        return resultado;
    }
}
