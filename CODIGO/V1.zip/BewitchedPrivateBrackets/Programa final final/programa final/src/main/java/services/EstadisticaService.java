package services;

import models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class EstadisticaService {

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private MensajeService mensajeService;

    @Autowired
    private EnvioService envioService;

    public Map<String, Object> obtenerEstadisticasGenerales() {
        List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
        List<Mensaje> mensajes = mensajeService.obtenerTodasLasPlantillas();
        List<MensajeEnviado> historial = envioService.obtenerHistorial();

        Map<String, Object> stats = new HashMap<>();

        long clientesActivos = clientes.stream().filter(c -> "activo".equals(c.getEstado())).count();
        long mensajesExitosos = historial.stream().filter(h -> "enviado".equals(h.getEstado())).count();
        long mensajesFallidos = historial.stream().filter(h -> "fallido".equals(h.getEstado())).count();

        stats.put("totalClientes", clientes != null ? clientes.size() : 0);
        stats.put("clientesActivos", clientesActivos);
        stats.put("clientesInactivos", clientes != null ? clientes.size() - clientesActivos : 0);
        stats.put("totalPlantillas", mensajes != null ? mensajes.size() : 0);
        stats.put("mensajesEnviados", historial != null ? historial.size() : 0);
        stats.put("totalMensajes", historial != null ? historial.size() : 0);
        stats.put("mensajesExitosos", mensajesExitosos);
        stats.put("mensajesFallidos", mensajesFallidos);

        if (historial.size() > 0) {
            double tasaExito = (mensajesExitosos * 100.0) / historial.size();
            stats.put("tasaExito", Math.round(tasaExito * 100.0) / 100.0);
        } else {
            stats.put("tasaExito", 0.0);
        }

        return stats;
    }

    public Map<String, Object> obtenerEstadisticasCompletas() {
        Map<String, Object> stats = obtenerEstadisticasGenerales();

        List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
        List<Mensaje> mensajes = mensajeService.obtenerTodasLasPlantillas();
        List<MensajeEnviado> historial = envioService.obtenerHistorial();

        // Estadísticas por canal
        Map<String, Long> enviosPorCanal = new HashMap<>();
        if (historial != null) {
            for (MensajeEnviado envio : historial) {
                String canal = envio.getCanal() != null ? envio.getCanal() : "SMS";
                enviosPorCanal.put(canal, enviosPorCanal.getOrDefault(canal, 0L) + 1);
            }
        }
        stats.put("enviosPorCanal", enviosPorCanal);

        // Estadísticas por estado
        Map<String, Long> enviosPorEstado = new HashMap<>();
        if (historial != null) {
            for (MensajeEnviado envio : historial) {
                String estado = "enviado".equals(envio.getEstado()) ? "exitoso" : "fallido";
                enviosPorEstado.put(estado, enviosPorEstado.getOrDefault(estado, 0L) + 1);
            }
        }
        stats.put("enviosPorEstado", enviosPorEstado);

        // Estadísticas por tipo de mensaje
        Map<String, Long> mensajesPorTipo = new HashMap<>();
        if (mensajes != null) {
            for (Mensaje mensaje : mensajes) {
                String tipo = mensaje.getTipo() != null ? mensaje.getTipo() : "sin_tipo";
                mensajesPorTipo.put(tipo, 
                    mensajesPorTipo.getOrDefault(tipo, 0L) + 1);
            }
        }
        stats.put("mensajesPorTipo", mensajesPorTipo);

        // Dominios de email más comunes
        Map<String, Long> dominios = new HashMap<>();
        if (clientes != null) {
            dominios = clientes.stream()
                .filter(c -> c.getEmail() != null && c.getEmail().contains("@"))
                .collect(Collectors.groupingBy(
                    c -> c.getEmail().substring(c.getEmail().indexOf("@") + 1),
                    Collectors.counting()
                ));
        }
        stats.put("dominiosComunes", dominios);

        // Mensajes enviados hoy
        LocalDateTime hoy = LocalDateTime.now();
        long mensajesHoy = 0;
        if (historial != null) {
            mensajesHoy = historial.stream()
                .filter(h -> h.getFechaEnvio() != null && 
                           h.getFechaEnvio().toLocalDate().equals(hoy.toLocalDate()))
                .count();
        }
        stats.put("mensajesHoy", mensajesHoy);

        return stats;
    }
}