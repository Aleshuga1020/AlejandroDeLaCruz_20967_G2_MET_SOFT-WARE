
package services;

import models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import com.opencsv.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class EnvioService {
    private final String CSV_FILE = "historial.csv";
    private List<MensajeEnviado> historial = new ArrayList<>();

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private MensajeService mensajeService;

    @Autowired
    private JavaMailSender emailSender;

    private String fromEmail = "sistema.mensajeria.temp@gmail.com";

    public EnvioService() {
        crearDirectorioSiNoExiste();
        cargarHistorialDesdeCSV();
    }

    private void crearDirectorioSiNoExiste() {
        try {
            Files.createDirectories(Paths.get("datos/historial"));
        } catch (Exception e) {
            System.err.println("Error creando directorio: " + e.getMessage());
        }
    }

    private void cargarHistorialDesdeCSV() {
        try {
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                crearArchivoCSVVacio();
                return;
            }

            historial.clear();
            try (CSVReader reader = new CSVReader(new FileReader(file))) {
                List<String[]> records = reader.readAll();
                for (int i = (records.size() > 0 && (records.get(0)[0].equals("ID_Cliente") || records.get(0)[0].equals("clienteId"))) ? 1 : 0; i < records.size(); i++) {
                    String[] record = records.get(i);
                    if (record.length >= 4 && !record[0].trim().isEmpty() && !record[0].trim().equals("clienteId") && !record[0].trim().equals("ID_Cliente")) {
                        try {
                            MensajeEnviado envio = new MensajeEnviado();
                            envio.setClienteId(Integer.parseInt(record[0].trim()));
                            envio.setMensajeId(Integer.parseInt(record[1].trim()));
                            
                            if (record.length > 2 && !record[2].trim().isEmpty()) {
                                try {
                                    envio.setFechaEnvio(LocalDateTime.parse(record[2].trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                                } catch (Exception e) {
                                    envio.setFechaEnvio(LocalDateTime.now());
                                }
                            } else {
                                envio.setFechaEnvio(LocalDateTime.now());
                            }
                            
                            if (record.length > 3) {
                                envio.setEstado(record[3].trim());
                            } else {
                                envio.setEstado("enviado");
                            }
                            
                            if (record.length >= 5) {
                                envio.setCanal(record[4].trim());
                            } else {
                                envio.setCanal("Email");
                            }
                            
                            historial.add(envio);
                        } catch (NumberFormatException e) {
                            System.err.println("Error al convertir número en línea: " + Arrays.toString(record));
                        } catch (Exception e) {
                            System.err.println("Error procesando registro: " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error cargando historial: " + e.getMessage());
        }
    }

    private void crearArchivoCSVVacio() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID_Cliente", "ID_Mensaje", "Fecha_Envio", "Estado_Envio", "Canal", "Observaciones"};
            writer.writeNext(header);
        } catch (Exception e) {
            System.err.println("Error creando archivo CSV: " + e.getMessage());
        }
    }

    public void guardarHistorialEnCSV() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID_Cliente", "ID_Mensaje", "Fecha_Envio", "Estado_Envio", "Canal", "Observaciones"};
            writer.writeNext(header);
            
            for (MensajeEnviado envio : historial) {
                String[] record = {
                    String.valueOf(envio.getClienteId()),
                    String.valueOf(envio.getMensajeId()),
                    envio.getFechaEnvio().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                    envio.getEstado(),
                    envio.getCanal() != null ? envio.getCanal() : "Email",
                    "enviado".equals(envio.getEstado()) ? "Enviado correctamente" : "Error en el envío"
                };
                writer.writeNext(record);
            }
        } catch (Exception e) {
            System.err.println("Error guardando historial: " + e.getMessage());
        }
    }

    public void enviarMensajeIndividual(int clienteId, int mensajeId, String canal) {
        try {
            Cliente cliente = clienteService.obtenerClientePorId(clienteId);
            Mensaje mensaje = mensajeService.obtenerPlantillaPorId(mensajeId);

            if (cliente == null) {
                throw new IllegalArgumentException("Cliente con ID " + clienteId + " no encontrado");
            }

            if (!"activo".equals(cliente.getEstado())) {
                throw new IllegalArgumentException("El cliente no está activo");
            }

            if (mensaje == null) {
                throw new IllegalArgumentException("Plantilla con ID " + mensajeId + " no encontrada");
            }

            String estado = "enviado";
            
            // Enviar correo electrónico
            if (cliente.getEmail() != null && !cliente.getEmail().isEmpty()) {
                try {
                    enviarCorreo(cliente.getEmail(), mensaje.getContenido());
                } catch (Exception e) {
                    System.err.println("Error enviando email a " + cliente.getEmail() + ": " + e.getMessage());
                    estado = "fallido";
                }
            }

            MensajeEnviado envio = new MensajeEnviado(clienteId, mensajeId, estado, "Email");
            historial.add(envio);
            guardarHistorialEnCSV();

        } catch (Exception e) {
            System.err.println("Error en envío individual: " + e.getMessage());
            throw new RuntimeException("Error al enviar mensaje: " + e.getMessage());
        }
    }

    public void enviarMensajeIndividual(int clienteId, int mensajeId) {
        enviarMensajeIndividual(clienteId, mensajeId, "Email");
    }

    public Map<String, Integer> enviarMensajeMasivo(int mensajeId) {
        return enviarMensajeMasivo(mensajeId, "Email");
    }

    public Map<String, Integer> enviarMensajeMasivo(int mensajeId, String canal) {
        try {
            List<Cliente> clientesActivos = clienteService.obtenerClientesActivos();
            Mensaje mensaje = mensajeService.obtenerPlantillaPorId(mensajeId);

            if (mensaje == null) {
                throw new IllegalArgumentException("Plantilla con ID " + mensajeId + " no encontrada");
            }

            if (clientesActivos.isEmpty()) {
                throw new IllegalArgumentException("No hay clientes activos para enviar mensajes");
            }

            int exitosos = 0;
            int fallidos = 0;

            for (int i = 0; i < clientesActivos.size(); i++) {
                Cliente cliente = clientesActivos.get(i);
                String estado = (i % 20 == 19) ? "fallido" : "enviado";

                if ("enviado".equals(estado)) {
                    exitosos++;
                    // Enviar correo electrónico
                    if (cliente.getEmail() != null && !cliente.getEmail().isEmpty()) {
                        try {
                            enviarCorreo(cliente.getEmail(), mensaje.getContenido());
                        } catch (Exception e) {
                            System.err.println("Error enviando email a " + cliente.getEmail() + ": " + e.getMessage());
                        }
                    }
                } else {
                    fallidos++;
                }

                MensajeEnviado envio = new MensajeEnviado(cliente.getId(), mensajeId, estado, "Email");
                historial.add(envio);
            }

            guardarHistorialEnCSV();

            Map<String, Integer> resultado = new HashMap<>();
            resultado.put("exitosos", exitosos);
            resultado.put("fallidos", fallidos);
            resultado.put("total", clientesActivos.size());

            return resultado;
        } catch (Exception e) {
            System.err.println("Error en envío masivo: " + e.getMessage());
            throw new RuntimeException("Error al enviar mensajes masivos: " + e.getMessage());
        }
    }

    private void enviarCorreo(String to, String text) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(to);
            message.setSubject("Mensaje Importante");
            message.setText(text);
            emailSender.send(message);
        } catch (Exception e) {
            System.err.println("Error enviando correo: " + e.getMessage());
            throw e;
        }
    }

    public List<MensajeEnviado> obtenerHistorial() {
        try {
            cargarHistorialDesdeCSV();
            List<MensajeEnviado> historialEnriquecido = new ArrayList<>();

            if (historial == null || historial.isEmpty()) {
                return historialEnriquecido;
            }

            for (MensajeEnviado envio : historial) {
                if (envio == null) continue;

                MensajeEnviado envioEnriquecido = new MensajeEnviado();
                envioEnriquecido.setClienteId(envio.getClienteId());
                envioEnriquecido.setMensajeId(envio.getMensajeId());
                envioEnriquecido.setEstado(envio.getEstado() != null ? envio.getEstado() : "desconocido");
                envioEnriquecido.setCanal(envio.getCanal() != null ? envio.getCanal() : "Email");
                envioEnriquecido.setFechaEnvio(envio.getFechaEnvio() != null ? envio.getFechaEnvio() : LocalDateTime.now());

                // Enriquecer con datos del cliente
                Cliente cliente = clienteService.obtenerClientePorId(envio.getClienteId());
                if (cliente != null) {
                    envioEnriquecido.setNombreCliente(cliente.getNombre());
                }

                // Enriquecer con datos del mensaje
                Mensaje mensaje = mensajeService.obtenerPlantillaPorId(envio.getMensajeId());
                if (mensaje != null) {
                    envioEnriquecido.setNombreMensaje(mensaje.getNombre());
                }

                historialEnriquecido.add(envioEnriquecido);
            }

            return historialEnriquecido;
        } catch (Exception e) {
            System.err.println("Error obteniendo historial: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
