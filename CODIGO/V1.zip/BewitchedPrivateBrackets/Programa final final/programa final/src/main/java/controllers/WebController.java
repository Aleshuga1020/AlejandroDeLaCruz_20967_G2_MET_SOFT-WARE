package controllers;

import models.*;
import services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

@Controller
public class WebController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private MensajeService mensajeService;

    @Autowired
    private EnvioService envioService;

    @Autowired
    private EstadisticaService estadisticaService;

    @Autowired
    private FechasConmemorativasService fechasConmemorativasService;

    @GetMapping("/")
    public String index() {
        return "login";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public String procesarLogin(@RequestParam String username, 
                               @RequestParam String password,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        Usuario usuario = usuarioService.validarCredenciales(username, password);
        if (usuario != null) {
            session.setAttribute("usuario", usuario);
            return "redirect:/dashboard";
        } else {
            redirectAttributes.addFlashAttribute("error", "Credenciales incorrectas");
            return "redirect:/login";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Map<String, Object> estadisticas = estadisticaService.obtenerEstadisticasGenerales();
        model.addAttribute("estadisticas", estadisticas);
        return "dashboard";
    }

    @GetMapping("/clientes")
    public String clientes(@RequestParam(required = false) String buscar,
                          @RequestParam(required = false) String estado,
                          Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<Cliente> clientes;
        
        if (buscar != null && !buscar.trim().isEmpty()) {
            clientes = clienteService.buscarClientes(buscar);
        } else if (estado != null && !estado.trim().isEmpty()) {
            clientes = clienteService.filtrarClientesPorEstado(estado);
        } else {
            clientes = clienteService.obtenerTodosLosClientes();
        }
        
        model.addAttribute("clientes", clientes);
        model.addAttribute("buscarTermino", buscar);
        model.addAttribute("estadoFiltro", estado);
        return "clientes";
    }

    @GetMapping("/cliente/nuevo")
    public String nuevoCliente(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        model.addAttribute("cliente", new Cliente());
        return "cliente-form";
    }

    @GetMapping("/clientes/editar/{id}")
    public String editarCliente(@PathVariable int id, Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Cliente cliente = clienteService.obtenerClientePorId(id);
        if (cliente == null) {
            return "redirect:/clientes";
        }

        model.addAttribute("cliente", cliente);
        return "cliente-form";
    }

    @PostMapping("/cliente/guardar")
    public String guardarCliente(@ModelAttribute Cliente cliente, 
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            if (cliente.getId() == 0) {
                clienteService.agregarCliente(cliente);
                redirectAttributes.addFlashAttribute("mensaje", "Cliente creado exitosamente");
            } else {
                clienteService.actualizarCliente(cliente);
                redirectAttributes.addFlashAttribute("mensaje", "Cliente actualizado exitosamente");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al guardar cliente: " + e.getMessage());
        }

        return "redirect:/clientes";
    }

    @GetMapping("/mensajes")
    public String mensajes(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<Mensaje> mensajes = mensajeService.obtenerTodasLasPlantillas();
        model.addAttribute("mensajes", mensajes);
        return "mensajes";
    }

    @GetMapping("/mensajes/nuevo")
    public String nuevoMensaje(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        model.addAttribute("mensaje", new Mensaje());
        model.addAttribute("editando", false);
        return "mensaje-form";
    }

    @GetMapping("/mensajes/editar/{id}")
    public String editarMensaje(@PathVariable int id, Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Mensaje mensaje = mensajeService.obtenerMensajePorId(id);
        if (mensaje == null) {
            return "redirect:/mensajes";
        }

        model.addAttribute("mensaje", mensaje);
        model.addAttribute("editando", true);
        return "mensaje-form";
    }

    @PostMapping("/mensajes/eliminar/{id}")
    public String eliminarMensaje(@PathVariable int id, HttpSession session, RedirectAttributes redirectAttributes) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            mensajeService.eliminarPlantilla(id);
            redirectAttributes.addFlashAttribute("mensaje", "Plantilla eliminada exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar plantilla: " + e.getMessage());
        }

        return "redirect:/mensajes";
    }

    @PostMapping("/mensajes")
    public String guardarMensaje(@ModelAttribute Mensaje mensaje, 
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            if (mensaje.getId() == 0) {
                mensajeService.crearPlantilla(mensaje);
                redirectAttributes.addFlashAttribute("mensaje", "Plantilla creada exitosamente");
            } else {
                mensajeService.editarPlantilla(mensaje.getId(), mensaje);
                redirectAttributes.addFlashAttribute("mensaje", "Plantilla actualizada exitosamente");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al guardar plantilla: " + e.getMessage());
        }

        return "redirect:/mensajes";
    }

    @PostMapping("/mensajes/actualizar")
    public String actualizarMensaje(@ModelAttribute Mensaje mensaje, 
                                   HttpSession session,
                                   RedirectAttributes redirectAttributes) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            mensajeService.editarPlantilla(mensaje.getId(), mensaje);
            redirectAttributes.addFlashAttribute("mensaje", "Plantilla actualizada exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar plantilla: " + e.getMessage());
        }

        return "redirect:/mensajes";
    }

    @GetMapping("/envios")
    public String envios(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<Cliente> clientesActivos = clienteService.obtenerClientesActivos();
        List<Mensaje> plantillas = mensajeService.obtenerTodasLasPlantillas();
        model.addAttribute("clientesActivos", clientesActivos);
        model.addAttribute("plantillas", plantillas);
        return "envios";
    }

    @PostMapping("/envios/individual")
    public String enviarMensajeIndividual(@RequestParam int clienteId, 
                                        @RequestParam int mensajeId,
                                        HttpSession session,
                                        RedirectAttributes redirectAttributes) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            envioService.enviarMensajeIndividual(clienteId, mensajeId);
            redirectAttributes.addFlashAttribute("mensaje", "Mensaje enviado exitosamente por email");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/envios";
    }

    @PostMapping("/envios/masivo")
    public String enviarMensajeMasivo(@RequestParam int mensajeId,
                                    HttpSession session,
                                    RedirectAttributes redirectAttributes) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            Map<String, Integer> resultado = envioService.enviarMensajeMasivo(mensajeId);
            redirectAttributes.addFlashAttribute("mensaje", 
                String.format("Envío masivo por email completado: %d exitosos, %d fallidos de %d total", 
                    resultado.get("exitosos"), resultado.get("fallidos"), resultado.get("total")));
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/envios";
    }

    @GetMapping("/historial")
    public String historial(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<MensajeEnviado> historial = envioService.obtenerHistorial();
        model.addAttribute("historial", historial);
        return "historial";
    }

    @GetMapping("/estadisticas")
    public String estadisticas(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Map<String, Object> estadisticas = estadisticaService.obtenerEstadisticasCompletas();
        model.addAttribute("estadisticas", estadisticas);
        return "estadisticas";
    }

    @GetMapping("/fechas-conmemorativas")
    public String fechasConmemorativas(Model model, HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            List<?> fechasProximas = fechasConmemorativasService.obtenerFechasProximas();
            String[] mensajeDelDia = fechasConmemorativasService.obtenerMensajeDelDia();
            model.addAttribute("fechasProximas", fechasProximas != null ? fechasProximas : new ArrayList<>());
            model.addAttribute("mensajeDelDia", mensajeDelDia);
        } catch (Exception e) {
            model.addAttribute("fechasProximas", new ArrayList<>());
            model.addAttribute("error", "Error al cargar fechas: " + e.getMessage());
        }

        return "fechas-conmemorativas";
    }

    @PostMapping("/fechas-conmemorativas/crear-mensajes")
    public String crearMensajesConmemorativos(HttpSession session, RedirectAttributes redirectAttributes) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            fechasConmemorativasService.crearMensajesConmemorativos();
            redirectAttributes.addFlashAttribute("mensaje", "Mensajes conmemorativos creados exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear mensajes: " + e.getMessage());
        }

        return "redirect:/mensajes";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/recuperar-contrasena")
    public String recuperarContrasena() {
        return "recuperar-contrasena";
    }

    @PostMapping("/recuperar-contrasena")
    public String procesarRecuperacion(@RequestParam String username,
                                      @RequestParam String codigoAdmin,
                                      @RequestParam String nuevaContrasena,
                                      RedirectAttributes redirectAttributes) {
        try {
            boolean exito = usuarioService.recuperarContrasena(username, codigoAdmin, nuevaContrasena);
            if (exito) {
                redirectAttributes.addFlashAttribute("mensaje", "Contraseña actualizada exitosamente");
                return "redirect:/login";
            } else {
                redirectAttributes.addFlashAttribute("error", "Código de administrador incorrecto");
                return "redirect:/recuperar-contrasena";
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
            return "redirect:/recuperar-contrasena";
        }
    }
}