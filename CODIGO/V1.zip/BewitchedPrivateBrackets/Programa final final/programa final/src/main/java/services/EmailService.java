
package services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {
    
    @Autowired
    private JavaMailSender mailSender;
    
    private final String FROM_EMAIL = "sistema.mensajeria.temp@gmail.com";
    
    public boolean enviarEmail(String destinatario, String asunto, String contenido) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(FROM_EMAIL);
            message.setTo(destinatario);
            message.setSubject(asunto);
            message.setText(contenido);
            
            // Simular envío (cambiar a mailSender.send(message) para envío real)
            System.out.println("EMAIL ENVIADO:");
            System.out.println("De: " + FROM_EMAIL);
            System.out.println("Para: " + destinatario);
            System.out.println("Asunto: " + asunto);
            System.out.println("Contenido: " + contenido);
            System.out.println("---");
            
            // Para envío real descomenta la siguiente línea:
            // mailSender.send(message);
            
            return true;
        } catch (Exception e) {
            System.err.println("Error enviando email: " + e.getMessage());
            return false;
        }
    }
}
