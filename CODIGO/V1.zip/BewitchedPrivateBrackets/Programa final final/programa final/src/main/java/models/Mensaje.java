
package models;

import java.time.LocalDateTime;

public class Mensaje {
    private int id;
    private String nombre;
    private String contenido;
    private String tipo;
    private LocalDateTime fechaCreacion;

    public Mensaje() {
        this.fechaCreacion = LocalDateTime.now();
    }

    public Mensaje(String nombre, String contenido, String tipo) {
        this.nombre = nombre;
        this.contenido = contenido;
        this.tipo = tipo;
        this.fechaCreacion = LocalDateTime.now();
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getContenido() { return contenido; }
    public void setContenido(String contenido) { this.contenido = contenido; }
    
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    
    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}
