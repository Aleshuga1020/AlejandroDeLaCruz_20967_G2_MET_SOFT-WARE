
package models;

import java.time.LocalDateTime;

public class Cliente {
    private int id;
    private String nombre;
    private String cedula;
    private String telefono;
    private String email;
    private String estado;
    private LocalDateTime fechaRegistro;

    public Cliente() {
        this.estado = "activo";
        this.fechaRegistro = LocalDateTime.now();
    }

    public Cliente(int id, String nombre, String cedula, String telefono, String email) {
        this.id = id;
        this.nombre = nombre;
        this.cedula = cedula;
        this.telefono = telefono;
        this.email = email;
        this.estado = "activo";
        this.fechaRegistro = LocalDateTime.now();
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }
    
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    
    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }
}
