
# Sistema de Mensajería - Programa Final

## Descripción
Sistema completo de mensajería desarrollado en Spring Boot con las siguientes funcionalidades:
- Gestión de clientes
- Gestión de mensajes/plantillas
- Envío de mensajes individuales y masivos
- Historial de envíos
- Estadísticas completas
- Sistema de autenticación

## Estructura del Proyecto
```
programa final/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   ├── com/example/
│   │   │   │   └── Main.java
│   │   │   ├── controllers/
│   │   │   │   └── WebController.java
│   │   │   ├── models/
│   │   │   │   ├── Cliente.java
│   │   │   │   ├── Mensaje.java
│   │   │   │   ├── MensajeEnviado.java
│   │   │   │   └── Usuario.java
│   │   │   └── services/
│   │   │       ├── ClienteService.java
│   │   │       ├── EnvioService.java
│   │   │       ├── EstadisticaService.java
│   │   │       ├── MensajeService.java
│   │   │       └── UsuarioService.java
│   │   └── resources/
│   │       ├── templates/
│   │       │   ├── login.html
│   │       │   ├── dashboard.html
│   │       │   ├── clientes.html
│   │       │   ├── mensajes.html
│   │       │   ├── envios.html
│   │       │   ├── historial.html
│   │       │   └── estadisticas.html
│   │       └── application.properties
├── datos/
├── pom.xml
├── usuarios.csv
├── clientes.csv
└── historial.csv
```

## Funcionalidades Implementadas

### 1. Sistema de Autenticación
- Login con usuario y contraseña
- Recuperación de contraseña con código de administrador
- Sesión de usuario

### 2. Gestión de Clientes
- Agregar nuevos clientes
- Editar información de clientes
- Listar todos los clientes
- Estados: activo/inactivo

### 3. Gestión de Mensajes
- Crear plantillas de mensajes
- Editar plantillas existentes
- Diferentes tipos de mensajes

### 4. Sistema de Envíos
- Envío individual de mensajes
- Envío masivo a todos los clientes activos
- Selección de canal (SMS, Email, WhatsApp)
- Simulación de fallos en envíos

### 5. Historial
- Registro completo de todos los envíos
- Estado de cada envío (enviado/fallido)
- Fecha y hora de envío
- Canal utilizado

### 6. Estadísticas
- Total de clientes y clientes activos
- Total de mensajes enviados
- Tasa de éxito en envíos
- Mensajes por tipo
- Dominios de email más comunes

## Configuración
- **Puerto**: 5000
- **Base de datos**: Archivos CSV
- **Framework**: Spring Boot 2.6.15
- **Java**: 11

## Usuarios por Defecto
- **Usuario**: admin / **Contraseña**: admin123
- **Usuario**: operador / **Contraseña**: op123
- **Código de administrador**: ADMIN2024

## Instalación y Ejecución
1. Asegurarse de tener Java 11 y Maven instalados
2. Ejecutar: `mvn clean compile`
3. Ejecutar: `mvn spring-boot:run`
4. Acceder a: `http://localhost:5000`

---

## PROMPT PARA REPLIT

**Contexto**: Este es un sistema de mensajería completo desarrollado en Spring Boot con Java 11. El sistema incluye gestión de clientes, mensajes, envíos, historial y estadísticas.

**Estructura actual**: El proyecto está en la carpeta "programa final" con toda la estructura Maven estándar.

**Funcionalidades principales**:
- Sistema de login con usuarios predefinidos
- Dashboard con estadísticas
- Gestión completa de clientes (CRUD)
- Gestión de plantillas de mensajes
- Envío individual y masivo de mensajes
- Historial de envíos con estados
- Estadísticas detalladas del sistema

**Tecnologías utilizadas**:
- Spring Boot 2.6.15
- Java 11
- Thymeleaf para templates
- OpenCSV para manejo de datos
- Maven como build tool
- Bootstrap para UI

**Datos de acceso**:
- Usuario: admin / Contraseña: admin123
- Usuario: operador / Contraseña: op123
- Código de administrador: ADMIN2024

**Configuración**:
- Puerto: 5000
- Dirección: 0.0.0.0
- Archivos de datos: CSV (usuarios.csv, clientes.csv, historial.csv)

**Comandos para ejecutar**:
```bash
cd "programa final"
mvn clean compile
mvn spring-boot:run
```

**Nota**: El sistema está completamente funcional y listo para usar. Todos los archivos necesarios están en la carpeta "programa final".
