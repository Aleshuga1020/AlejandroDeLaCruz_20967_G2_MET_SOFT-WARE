
{ pkgs ? import <nixpkgs> {} }:

pkgs.mkShell {
  buildInputs = with pkgs; [
    openjdk11
    maven
  ];

  shellHook = ''
    export JAVA_HOME=${pkgs.openjdk11}
    export PATH=$JAVA_HOME/bin:$PATH
    echo "Java y Maven están configurados correctamente"
    java -version
    mvn --version
  '';
}
