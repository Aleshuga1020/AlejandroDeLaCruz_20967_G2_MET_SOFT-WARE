
# 📊 Instrucciones para usar las plantillas con Excel

## Abrir archivos CSV en Excel

1. **Abrir Excel**
2. **Archivo > Abrir**
3. Seleccionar el archivo `.csv` deseado
4. En el asistente de importación:
   - Tipo de archivo: "Delimitado"
   - Delimitador: "Coma"
   - Encoding: "UTF-8"

## Guardar cambios

1. **Archivo > Guardar como**
2. Formato: "CSV (delimitado por comas)"
3. Mantener el nombre original del archivo

## Consejos importantes

- ⚠️ **NO eliminar** la primera fila (encabezados)
- ⚠️ **Mantener el formato** de fechas: YYYY-MM-DD
- ⚠️ **No usar comas** dentro del contenido de los campos
- ⚠️ **Usar comillas dobles** si necesitas incluir comas en el texto

## Campos obligatorios por plantilla

### Clientes
- ✅ Nombre (no vacío)
- ✅ Telefono (formato: +52-555-0123)
- ✅ Email (formato válido)

### Mensajes
- ✅ Contenido (no vacío)
- ✅ Tipo (bienvenida/promocional/recordatorio/confirmacion)

### Historial
- ✅ ID_Cliente (debe existir)
- ✅ ID_Mensaje (debe existir)
- ✅ Estado_Envio (enviado/pendiente/fallido)
