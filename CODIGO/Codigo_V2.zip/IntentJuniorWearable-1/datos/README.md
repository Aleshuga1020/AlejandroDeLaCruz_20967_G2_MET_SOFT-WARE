
# Estructura de Datos del Sistema de Mensajería

## Carpetas y Archivos de Plantilla

### 📁 clientes/
- **plantilla_clientes.csv**: Plantilla para importar datos de clientes
  - ID: Identificador único del cliente
  - Nombre: Nombre completo del cliente
  - Telefono: Número de teléfono (formato internacional)
  - Email: Dirección de correo electrónico
  - Estado: activo/inactivo
  - Fecha_Registro: Fecha de alta del cliente

### 📁 mensajes/
- **plantilla_mensajes.csv**: Plantilla para crear mensajes predefinidos
  - ID: Identificador único del mensaje
  - Contenido: Texto del mensaje
  - Tipo: bienvenida/promocional/recordatorio/confirmacion
  - Fecha_Creacion: Fecha de creación del mensaje
  - Activo: si/no

### 📁 historial/
- **plantilla_historial.csv**: Plantilla para el historial de envíos
  - ID_Cliente: Referencia al cliente
  - ID_Mensaje: Referencia al mensaje enviado
  - Fecha_Envio: Timestamp del envío
  - Estado_Envio: enviado/pendiente/fallido
  - Canal: SMS/Email/WhatsApp
  - Observaciones: Notas adicionales

### 📁 plantillas/
- **plantilla_campanas.csv**: Plantilla para gestionar campañas
  - ID_Campana: Identificador único de la campaña
  - Nombre_Campana: Nombre descriptivo
  - Tipo_Mensaje: Tipo de mensaje a enviar
  - Fecha_Inicio/Fin: Periodo de la campaña
  - Estado: activa/programada/finalizada
  - Estadísticas de envío

## Uso de las Plantillas

1. **Para agregar clientes**: Edita `plantilla_clientes.csv` con los datos reales
2. **Para crear mensajes**: Modifica `plantilla_mensajes.csv` con tus mensajes
3. **Para revisar historial**: Consulta `plantilla_historial.csv`
4. **Para planificar campañas**: Usa `plantilla_campanas.csv`

## Formatos Compatibles

- ✅ CSV (Valores separados por comas)
- ✅ Compatible con Excel, Google Sheets, LibreOffice Calc
- ✅ Encoding UTF-8 para caracteres especiales
