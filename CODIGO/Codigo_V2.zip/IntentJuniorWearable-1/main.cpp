#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <ctime>
#include <iomanip>
#include <algorithm>
#include <cstring>

struct Cliente {
    int id;
    std::string nombre;
    std::string telefono;
    std::string email;
    std::string estado; // "activo", "inactivo"

    Cliente(int _id, const std::string& _nombre, const std::string& _telefono, 
            const std::string& _email) 
        : id(_id), nombre(_nombre), telefono(_telefono), email(_email), estado("activo") {}
};

struct Mensaje {
    int id;
    std::string contenido;
    std::string tipo;
    std::time_t fechaCreacion;

    Mensaje(int _id, const std::string& _contenido, const std::string& _tipo)
        : id(_id), contenido(_contenido), tipo(_tipo) {
        fechaCreacion = std::time(nullptr);
    }
};

struct MensajeEnviado {
    int clienteId;
    int mensajeId;
    std::time_t fechaEnvio;
    std::string estado;

    MensajeEnviado(int _clienteId, int _mensajeId, const std::string& _estado)
        : clienteId(_clienteId), mensajeId(_mensajeId), estado(_estado) {
        fechaEnvio = std::time(nullptr);
    }
};

class SistemaMensajeria {
private:
    std::vector<Cliente> clientes;
    std::vector<Mensaje> plantillas;
    std::vector<MensajeEnviado> historial;
    int proximoIdCliente;
    int proximoIdMensaje;

public:
    SistemaMensajeria() : proximoIdCliente(1), proximoIdMensaje(1) {
        inicializarPlantillas();
    }

    bool iniciarSesion() {
        std::string usuario, contrasena;
        int intentos = 0;
        const int maxIntentos = 3;

        std::cout << "\n" << std::string(50, '=') << std::endl;
        std::cout << "       INICIO DE SESIÓN" << std::endl;
        std::cout << std::string(50, '=') << std::endl;

        while (intentos < maxIntentos) {
            std::cout << "\nUsuario: ";
            std::cin >> usuario;
            std::cout << "Contraseña: ";
            std::cin >> contrasena;

            if (usuario == "administrador" && contrasena == "administrador001") {
                std::cout << "\n¡Inicio de sesión exitoso!" << std::endl;
                std::cout << "Bienvenido al Sistema de Mensajería Automática" << std::endl;
                return true;
            } else {
                intentos++;
                std::cout << "\nCredenciales incorrectas. ";
                if (intentos < maxIntentos) {
                    std::cout << "Intentos restantes: " << (maxIntentos - intentos) << std::endl;
                } else {
                    std::cout << "Máximo número de intentos alcanzado.\nAcceso denegado." << std::endl;
                }
            }
        }

        return false;
    }

    void inicializarPlantillas() {
        plantillas.push_back(Mensaje(proximoIdMensaje++, "¡Bienvenido a nuestros servicios! Gracias por confiar en nosotros.", "bienvenida"));
        plantillas.push_back(Mensaje(proximoIdMensaje++, "¡Oferta especial! 20% de descuento en todos nuestros productos. ¡No te lo pierdas!", "promocional"));
        plantillas.push_back(Mensaje(proximoIdMensaje++, "Recordatorio: Tienes una cita pendiente con nosotros. ¡Te esperamos!", "recordatorio"));
        plantillas.push_back(Mensaje(proximoIdMensaje++, "Gracias por tu compra. Tu pedido está siendo procesado.", "confirmacion"));
    }

    void agregarCliente() {
        std::string nombre, telefono, email;
        std::cout << "\n=== AGREGAR NUEVO CLIENTE ===\n";
        std::cout << "Nombre: ";
        std::cin.ignore();
        std::getline(std::cin, nombre);

        do {
            std::cout << "Teléfono (10 dígitos): ";
            std::getline(std::cin, telefono);
            if (telefono.length() != 10 || !std::all_of(telefono.begin(), telefono.end(), ::isdigit)) {
                std::cout << "Error: El teléfono debe contener exactamente 10 números.\n";
            } else {
                break;
            }
        } while (true);

        std::cout << "Email: ";
        std::getline(std::cin, email);

        clientes.push_back(Cliente(proximoIdCliente++, nombre, telefono, email));
        std::cout << "Cliente agregado exitosamente con ID: " << (proximoIdCliente - 1) << std::endl;
    }

    void editarCliente() {
        if (clientes.empty()) {
            std::cout << "No hay clientes registrados.\n";
            return;
        }

        listarClientes();

        int clienteId;
        std::cout << "\nIngrese el ID del cliente a editar: ";
        std::cin >> clienteId;
        std::cin.ignore();

        auto clienteIt = std::find_if(clientes.begin(), clientes.end(),
            [clienteId](const Cliente& c) { return c.id == clienteId; });

        if (clienteIt == clientes.end()) {
            std::cout << "Cliente no encontrado.\n";
            return;
        }

        std::string nuevoValor;
        int opcion;
        std::cout << "\n=== EDITAR CLIENTE ===\n";
        std::cout << "1. Nombre\n2. Teléfono\n3. Email\n4. Estado\n5. Editar todo\nSeleccione una opción: ";
        std::cin >> opcion;
        std::cin.ignore();

        switch (opcion) {
            case 1:
                std::cout << "Nuevo nombre: ";
                std::getline(std::cin, clienteIt->nombre);
                break;
            case 2:
                do {
                    std::cout << "Nuevo teléfono (10 dígitos): ";
                    std::getline(std::cin, nuevoValor);
                    if (nuevoValor.length() != 10 || !std::all_of(nuevoValor.begin(), nuevoValor.end(), ::isdigit)) {
                        std::cout << "Error: El teléfono debe contener exactamente 10 números.\n";
                    } else {
                        clienteIt->telefono = nuevoValor;
                        break;
                    }
                } while (true);
                break;
            case 3:
                std::cout << "Nuevo email: ";
                std::getline(std::cin, clienteIt->email);
                break;
            case 4:
                std::cout << "Nuevo estado (activo/inactivo): ";
                std::getline(std::cin, nuevoValor);
                if (nuevoValor == "activo" || nuevoValor == "inactivo") {
                    clienteIt->estado = nuevoValor;
                } else {
                    std::cout << "Estado inválido.\n";
                }
                break;
            case 5:
                std::cout << "Nuevo nombre: ";
                std::getline(std::cin, clienteIt->nombre);
                do {
                    std::cout << "Nuevo teléfono (10 dígitos): ";
                    std::getline(std::cin, clienteIt->telefono);
                    if (clienteIt->telefono.length() != 10 || !std::all_of(clienteIt->telefono.begin(), clienteIt->telefono.end(), ::isdigit)) {
                        std::cout << "Error: El teléfono debe contener exactamente 10 números.\n";
                    } else {
                        break;
                    }
                } while (true);
                std::cout << "Nuevo email: ";
                std::getline(std::cin, clienteIt->email);
                std::cout << "Nuevo estado (activo/inactivo): ";
                std::getline(std::cin, nuevoValor);
                if (nuevoValor == "activo" || nuevoValor == "inactivo") {
                    clienteIt->estado = nuevoValor;
                }
                break;
            default:
                std::cout << "Opción no válida.\n";
                return;
        }
        std::cout << "Datos actualizados exitosamente.\n";
    }

    void listarClientes() {
        std::cout << "\n=== LISTA DE CLIENTES ===\n";
        if (clientes.empty()) {
            std::cout << "No hay clientes registrados.\n";
            return;
        }
        std::cout << std::left << std::setw(5) << "ID" << std::setw(20) << "Nombre"
                  << std::setw(15) << "Teléfono" << std::setw(25) << "Email"
                  << std::setw(10) << "Estado" << std::endl;
        for (const auto& cliente : clientes) {
            std::cout << std::left << std::setw(5) << cliente.id << std::setw(20) << cliente.nombre
                      << std::setw(15) << cliente.telefono << std::setw(25) << cliente.email
                      << std::setw(10) << cliente.estado << std::endl;
        }
    }

    void ejecutar() {
        if (!iniciarSesion()) return;

        int opcion;
        do {
            std::cout << "\n" << std::string(50, '=') << std::endl;
            std::cout << "    SISTEMA DE MENSAJERÍA AUTOMÁTICA" << std::endl;
            std::cout << std::string(50, '=') << std::endl;
            std::cout << "1. Agregar cliente\n2. Listar clientes\n";
            std::cout << "3. Enviar mensaje individual\n4. Enviar mensaje masivo\n";
            std::cout << "5. Ver plantillas de mensajes\n6. Crear nueva plantilla\n";
            std::cout << "7. Ver historial de mensajes\n8. Ver estadísticas\n0. Salir\n";
            std::cout << std::string(50, '-') << std::endl;

            std::string entrada;
            bool entradaValida = false;
            do {
                std::cout << "Seleccione una opci\xF3n: ";
                std::cin >> entrada;
                if (entrada.length() == 1 && std::isdigit(entrada[0])) {
                    opcion = entrada[0] - '0';
                    entradaValida = true;
                } else {
                    std::cout << "Error: Ingrese solo un número entre 0 y 8.\n";
                }
            } while (!entradaValida);

            switch (opcion) {
                case 1: agregarCliente(); break;
                case 2: listarClientes(); break;
                case 3: 
                    std::cout << "Función de envío individual en desarrollo.\n"; 
                    break;
                case 4: 
                    std::cout << "Función de envío masivo en desarrollo.\n"; 
                    break;
                case 5: 
                    std::cout << "Mostrando plantillas de mensajes en desarrollo.\n"; 
                    break;
                case 6: 
                    std::cout << "Creación de plantillas en desarrollo.\n"; 
                    break;
                case 7: 
                    std::cout << "Historial de mensajes en desarrollo.\n"; 
                    break;
                case 8: 
                    std::cout << "Estadísticas en desarrollo.\n"; 
                    break;
                case 0:
                    std::cout << "¡Gracias por usar el sistema de mensajería!\n";
                    break;
                default:
                    std::cout << "Opción no válida. Seleccione entre 0 y 8.\n";
            }
            if (opcion != 0) {
                std::cout << "\nPresione Enter para continuar...";
                std::cin.ignore();
                std::cin.get();
            }
        } while (opcion != 0);
    }
};

int main() {
    std::cout << "Iniciando Sistema de Mensajería Automática para Clientes...\n";
    SistemaMensajeria sistema;
    sistema.ejecutar();
    return 0;
}