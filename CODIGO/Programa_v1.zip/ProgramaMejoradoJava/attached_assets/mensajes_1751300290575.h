
#ifndef MENSAJES_H
#define MENSAJES_H

#include "estructuras.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <ctime>

class GestorMensajes {
private:
    std::vector<Mensaje>& plantillas;
    int& proximoIdMensaje;

public:
    GestorMensajes(std::vector<Mensaje>& _plantillas, int& _proximoIdMensaje)
        : plantillas(_plantillas), proximoIdMensaje(_proximoIdMensaje) {}
    
    void cargarPlantillasDesdeCSV() {
        std::ifstream archivo("datos/mensajes/plantilla_mensajes.csv");
        if (!archivo.is_open()) {
            std::cout << "Archivo de plantillas no encontrado, usando plantillas por defecto.\n";
            return;
        }

        plantillas.clear();
        std::string linea;
        bool primeraLinea = true;
        
        while (std::getline(archivo, linea)) {
            if (primeraLinea) {
                primeraLinea = false;
                continue;
            }
            
            if (linea.empty()) continue;
            
            std::stringstream ss(linea);
            std::string campo;
            std::vector<std::string> campos;
            
            bool enComillas = false;
            std::string campoActual;
            
            for (char c : linea) {
                if (c == '"') {
                    enComillas = !enComillas;
                } else if (c == ',' && !enComillas) {
                    campos.push_back(campoActual);
                    campoActual.clear();
                } else {
                    campoActual += c;
                }
            }
            campos.push_back(campoActual);
            
            if (campos.size() >= 3 && !campos[0].empty()) {
                try {
                    int id = std::stoi(campos[0]);
                    plantillas.push_back(Mensaje(id, campos[1], campos[2]));
                    
                    if (id >= proximoIdMensaje) {
                        proximoIdMensaje = id + 1;
                    }
                } catch (const std::invalid_argument& e) {
                    std::cout << "Error: ID inválido en línea del CSV de mensajes, saltando línea.\n";
                    continue;
                } catch (const std::out_of_range& e) {
                    std::cout << "Error: ID fuera de rango en línea del CSV de mensajes, saltando línea.\n";
                    continue;
                }
            }
        }
        archivo.close();
    }

    void guardarPlantillasEnCSV() {
        std::ofstream archivo("datos/mensajes/plantilla_mensajes.csv");
        if (!archivo.is_open()) {
            std::cout << "Error: No se pudo abrir el archivo de plantillas para escritura.\n";
            return;
        }

        archivo << "ID,Contenido,Tipo,Fecha_Creacion,Activo\n";
        
        for (const auto& plantilla : plantillas) {
            std::tm* timeinfo = std::localtime(&plantilla.fechaCreacion);
            
            std::string contenidoEscapado = plantilla.contenido;
            size_t pos = 0;
            while ((pos = contenidoEscapado.find("\"", pos)) != std::string::npos) {
                contenidoEscapado.replace(pos, 1, "\"\"");
                pos += 2;
            }
            
            archivo << plantilla.id << ",\""
                   << contenidoEscapado << "\","
                   << plantilla.tipo << ","
                   << (timeinfo->tm_year + 1900) << "-"
                   << std::setfill('0') << std::setw(2) << (timeinfo->tm_mon + 1) << "-"
                   << std::setfill('0') << std::setw(2) << timeinfo->tm_mday << ","
                   << "si\n";
        }
        
        archivo.close();
    }

    void verPlantillasMensajes() {
        std::cout << "\n=== PLANTILLAS DE MENSAJES ===\n";
        if (plantillas.empty()) {
            std::cout << "No hay plantillas de mensajes disponibles.\n";
            return;
        }
        
        std::cout << std::left << std::setw(5) << "ID" << std::setw(15) << "Tipo"
                  << std::setw(50) << "Contenido" << std::setw(12) << "Fecha" << std::endl;
        std::cout << std::string(82, '-') << std::endl;
        
        for (const auto& plantilla : plantillas) {
            std::tm* timeinfo = std::localtime(&plantilla.fechaCreacion);
            std::string fecha = std::to_string(timeinfo->tm_year + 1900) + "-" +
                               std::to_string(timeinfo->tm_mon + 1) + "-" +
                               std::to_string(timeinfo->tm_mday);
            
            std::string contenidoCorto = plantilla.contenido;
            if (contenidoCorto.length() > 47) {
                contenidoCorto = contenidoCorto.substr(0, 47) + "...";
            }
            
            std::cout << std::left << std::setw(5) << plantilla.id 
                      << std::setw(15) << plantilla.tipo
                      << std::setw(50) << contenidoCorto
                      << std::setw(12) << fecha << std::endl;
        }
    }

    void crearNuevaPlantilla() {
        std::string contenido, tipo;
        int tipoOpcion;
        
        std::cout << "\n=== CREAR NUEVA PLANTILLA DE MENSAJE ===\n";
        
        std::cout << "Tipos de mensaje disponibles:\n";
        std::cout << "1. Bienvenida\n2. Promocional\n3. Recordatorio\n4. Confirmación\n";
        std::cout << "Seleccione el tipo (1-4): ";
        
        std::string entrada;
        bool entradaValida = false;
        do {
            std::cin >> entrada;
            if (entrada.length() == 1 && std::isdigit(entrada[0])) {
                tipoOpcion = entrada[0] - '0';
                if (tipoOpcion >= 1 && tipoOpcion <= 4) {
                    entradaValida = true;
                } else {
                    std::cout << "Error: Seleccione una opción entre 1 y 4: ";
                }
            } else {
                std::cout << "Error: Ingrese solo un número entre 1 y 4: ";
            }
        } while (!entradaValida);
        
        switch (tipoOpcion) {
            case 1: tipo = "bienvenida"; break;
            case 2: tipo = "promocional"; break;
            case 3: tipo = "recordatorio"; break;
            case 4: tipo = "confirmacion"; break;
        }
        
        std::cout << "\nIngrese el contenido del mensaje:\n";
        std::cin.ignore();
        std::getline(std::cin, contenido);
        
        if (contenido.empty()) {
            std::cout << "Error: El contenido no puede estar vacío.\n";
            return;
        }
        
        plantillas.push_back(Mensaje(proximoIdMensaje++, contenido, tipo));
        guardarPlantillasEnCSV();
        
        std::cout << "\n✓ Plantilla creada exitosamente con ID: " << (proximoIdMensaje - 1) << std::endl;
        std::cout << "✓ Tipo: " << tipo << std::endl;
        std::cout << "✓ Plantilla sincronizada con Excel en: datos/mensajes/plantilla_mensajes.csv" << std::endl;
    }
};

#endif
