
#include "sistema.h"

int main() {
    SistemaMensajeria sistema;
    sistema.ejecutar();
    return 0;
}
