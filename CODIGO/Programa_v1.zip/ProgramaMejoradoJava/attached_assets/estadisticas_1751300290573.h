
#ifndef ESTADISTICAS_H
#define ESTADISTICAS_H

#include "estructuras.h"
#include <vector>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <map>
#include <ctime>

class GestorEstadisticas {
private:
    std::vector<Cliente>& clientes;
    std::vector<Mensaje>& plantillas;
    std::vector<MensajeEnviado>& historial;

public:
    GestorEstadisticas(std::vector<Cliente>& _clientes, std::vector<Mensaje>& _plantillas, 
                      std::vector<MensajeEnviado>& _historial)
        : clientes(_clientes), plantillas(_plantillas), historial(_historial) {}
    
    void verEstadisticas() {
        std::cout << "\n" << std::string(60, '=') << std::endl;
        std::cout << "           ESTADÍSTICAS DEL SISTEMA" << std::endl;
        std::cout << std::string(60, '=') << std::endl;

        mostrarEstadisticasGenerales();
        mostrarEstadisticasEnvios();
        mostrarEstadisticasClientes();
        mostrarEstadisticasMensajes();
        mostrarAnalisisRendimiento();
    }

private:
    void mostrarEstadisticasGenerales() {
        std::cout << "\n📊 ESTADÍSTICAS GENERALES:\n";
        std::cout << std::string(40, '-') << std::endl;
        
        std::cout << "📁 Total de clientes registrados: " << clientes.size() << std::endl;
        
        int clientesActivos = 0;
        for (const auto& cliente : clientes) {
            if (cliente.estado == "activo") clientesActivos++;
        }
        
        std::cout << "✅ Clientes activos: " << clientesActivos << std::endl;
        std::cout << "❌ Clientes inactivos: " << (clientes.size() - clientesActivos) << std::endl;
        std::cout << "📝 Total de plantillas de mensajes: " << plantillas.size() << std::endl;
        std::cout << "📤 Total de mensajes enviados: " << historial.size() << std::endl;
    }

    void mostrarEstadisticasEnvios() {
        if (historial.empty()) {
            std::cout << "\n📤 ESTADÍSTICAS DE ENVÍOS: No hay datos disponibles\n";
            return;
        }

        std::cout << "\n📤 ESTADÍSTICAS DE ENVÍOS:\n";
        std::cout << std::string(40, '-') << std::endl;
        
        int exitosos = 0, fallidos = 0;
        for (const auto& envio : historial) {
            if (envio.estado == "enviado") exitosos++;
            else fallidos++;
        }
        
        double tasaExito = (historial.size() > 0) ? (exitosos * 100.0 / historial.size()) : 0;
        
        std::cout << "✅ Mensajes enviados exitosamente: " << exitosos << std::endl;
        std::cout << "❌ Mensajes fallidos: " << fallidos << std::endl;
        std::cout << "📈 Tasa de éxito: " << std::fixed << std::setprecision(2) << tasaExito << "%" << std::endl;
        
        std::time_t ahora = std::time(nullptr);
        std::tm* hoy = std::localtime(&ahora);
        
        int mensajesHoy = 0;
        for (const auto& envio : historial) {
            std::tm* fechaEnvio = std::localtime(&envio.fechaEnvio);
            if (fechaEnvio->tm_year == hoy->tm_year &&
                fechaEnvio->tm_mon == hoy->tm_mon &&
                fechaEnvio->tm_mday == hoy->tm_mday) {
                mensajesHoy++;
            }
        }
        
        std::cout << "📅 Mensajes enviados hoy: " << mensajesHoy << std::endl;
    }

    void mostrarEstadisticasClientes() {
        std::cout << "\n👥 ESTADÍSTICAS DE CLIENTES:\n";
        std::cout << std::string(40, '-') << std::endl;
        
        if (clientes.empty()) {
            std::cout << "No hay clientes registrados.\n";
            return;
        }

        std::map<int, int> mensajesPorCliente;
        for (const auto& envio : historial) {
            mensajesPorCliente[envio.clienteId]++;
        }
        
        if (!mensajesPorCliente.empty()) {
            auto clienteTop = std::max_element(mensajesPorCliente.begin(), mensajesPorCliente.end(),
                [](const std::pair<int, int>& a, const std::pair<int, int>& b) {
                    return a.second < b.second;
                });
            
            auto clienteIt = std::find_if(clientes.begin(), clientes.end(),
                [&clienteTop](const Cliente& c) { return c.id == clienteTop->first; });
            
            if (clienteIt != clientes.end()) {
                std::cout << "⭐ Cliente más activo: " << clienteIt->nombre 
                          << " (" << clienteTop->second << " mensajes)" << std::endl;
            }
        }
        
        std::map<std::string, int> dominios;
        for (const auto& cliente : clientes) {
            size_t posArroba = cliente.email.find('@');
            if (posArroba != std::string::npos) {
                std::string dominio = cliente.email.substr(posArroba + 1);
                dominios[dominio]++;
            }
        }
        
        std::cout << "📧 Dominios de email más comunes:\n";
        for (const auto& dominio : dominios) {
            if (dominio.second > 1) {
                std::cout << "   • " << dominio.first << ": " << dominio.second << " clientes" << std::endl;
            }
        }
    }

    void mostrarEstadisticasMensajes() {
        std::cout << "\n💬 ESTADÍSTICAS DE MENSAJES:\n";
        std::cout << std::string(40, '-') << std::endl;
        
        if (plantillas.empty()) {
            std::cout << "No hay plantillas de mensajes.\n";
            return;
        }

        std::map<std::string, int> tiposUtilizados;
        for (const auto& envio : historial) {
            auto plantillaIt = std::find_if(plantillas.begin(), plantillas.end(),
                [&envio](const Mensaje& m) { return m.id == envio.mensajeId; });
            
            if (plantillaIt != plantillas.end()) {
                tiposUtilizados[plantillaIt->tipo]++;
            }
        }
        
        std::cout << "📋 Plantillas disponibles por tipo:\n";
        std::map<std::string, int> tiposPorCategoria;
        for (const auto& plantilla : plantillas) {
            tiposPorCategoria[plantilla.tipo]++;
        }
        
        for (const auto& tipo : tiposPorCategoria) {
            std::cout << "   • " << tipo.first << ": " << tipo.second << " plantillas" << std::endl;
        }
        
        if (!tiposUtilizados.empty()) {
            std::cout << "\n📊 Uso de plantillas:\n";
            for (const auto& tipo : tiposUtilizados) {
                std::cout << "   • " << tipo.first << ": " << tipo.second << " envíos" << std::endl;
            }
        }
    }

    void mostrarAnalisisRendimiento() {
        std::cout << "\n⚡ ANÁLISIS DE RENDIMIENTO:\n";
        std::cout << std::string(40, '-') << std::endl;
        
        if (historial.empty()) {
            std::cout << "No hay datos suficientes para análisis.\n";
            return;
        }

        int clientesActivos = 0;
        for (const auto& cliente : clientes) {
            if (cliente.estado == "activo") clientesActivos++;
        }
        
        if (clientesActivos > 0) {
            double promedioMensajes = static_cast<double>(historial.size()) / clientesActivos;
            std::cout << "📊 Promedio de mensajes por cliente activo: " 
                      << std::fixed << std::setprecision(2) << promedioMensajes << std::endl;
        }
        
        std::cout << "\n💡 RECOMENDACIONES:\n";
        std::cout << std::string(40, '-') << std::endl;
        
        if (clientesActivos == 0) {
            std::cout << "⚠️  No hay clientes activos. Considera reactivar clientes inactivos.\n";
        }
        
        int clientesInactivos = clientes.size() - clientesActivos;
        if (clientesInactivos > clientesActivos) {
            std::cout << "⚠️  Hay más clientes inactivos que activos. Revisa la estrategia de retención.\n";
        }
        
        if (historial.size() > 0) {
            int fallidos = 0;
            for (const auto& envio : historial) {
                if (envio.estado == "fallido") fallidos++;
            }
            
            double tasaFallo = (fallidos * 100.0) / historial.size();
            if (tasaFallo > 10) {
                std::cout << "⚠️  Tasa de fallos alta (" << std::fixed << std::setprecision(1) 
                          << tasaFallo << "%). Revisa la configuración de envío.\n";
            }
        }
        
        if (plantillas.size() < 5) {
            std::cout << "💡 Considera crear más plantillas para diversificar los mensajes.\n";
        }
        
        std::cout << "✅ Sistema funcionando correctamente.\n";
    }
};

#endif
