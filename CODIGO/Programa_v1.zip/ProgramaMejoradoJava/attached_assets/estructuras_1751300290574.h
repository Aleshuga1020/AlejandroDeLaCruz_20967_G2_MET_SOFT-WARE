
#ifndef ESTRUCTURAS_H
#define ESTRUCTURAS_H

#include <string>
#include <ctime>

struct Cliente {
    int id;
    std::string nombre;
    std::string telefono;
    std::string email;
    std::string estado; // "activo", "inactivo"

    Cliente(int _id, const std::string& _nombre, const std::string& _telefono, 
            const std::string& _email) 
        : id(_id), nombre(_nombre), telefono(_telefono), email(_email), estado("activo") {}
};

struct Mensaje {
    int id;
    std::string contenido;
    std::string tipo;
    std::time_t fechaCreacion;

    Mensaje(int _id, const std::string& _contenido, const std::string& _tipo)
        : id(_id), contenido(_contenido), tipo(_tipo) {
        fechaCreacion = std::time(nullptr);
    }
};

struct MensajeEnviado {
    int clienteId;
    int mensajeId;
    std::time_t fechaEnvio;
    std::string estado;

    MensajeEnviado(int _clienteId, int _mensajeId, const std::string& _estado)
        : clienteId(_clienteId), mensajeId(_mensajeId), estado(_estado) {
        fechaEnvio = std::time(nullptr);
    }
};

#endif
