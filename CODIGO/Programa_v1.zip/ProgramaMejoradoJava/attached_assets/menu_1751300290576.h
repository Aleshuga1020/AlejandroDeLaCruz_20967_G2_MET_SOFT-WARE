
#ifndef MENU_H
#define MENU_H

#include <iostream>
#include <string>
#include <cctype>

class MenuSistema {
public:
    MenuSistema() {}
    
    bool iniciarSesion() {
        std::string usuario, contrasena;
        int intentos = 0;
        const int maxIntentos = 3;

        std::cout << "\n" << std::string(50, '=') << std::endl;
        std::cout << "       INICIO DE SESIÓN" << std::endl;
        std::cout << std::string(50, '=') << std::endl;

        while (intentos < maxIntentos) {
            std::cout << "\nUsuario: ";
            std::cin >> usuario;
            std::cout << "Contraseña: ";
            std::cin >> contrasena;

            if (usuario == "administrador" && contrasena == "administrador001") {
                std::cout << "\n¡Inicio de sesión exitoso!" << std::endl;
                std::cout << "Bienvenido al Sistema de Mensajería Automática" << std::endl;
                return true;
            } else {
                intentos++;
                std::cout << "\nCredenciales incorrectas. ";
                if (intentos < maxIntentos) {
                    std::cout << "Intentos restantes: " << (maxIntentos - intentos) << std::endl;
                } else {
                    std::cout << "Máximo número de intentos alcanzado.\nAcceso denegado." << std::endl;
                }
            }
        }

        return false;
    }

    void mostrarMenuPrincipal() {
        std::cout << "\n" << std::string(50, '=') << std::endl;
        std::cout << "    SISTEMA DE MENSAJERÍA AUTOMÁTICA" << std::endl;
        std::cout << std::string(50, '=') << std::endl;
        std::cout << "1. Agregar cliente (se guarda en Excel)\n";
        std::cout << "2. Listar clientes\n";
        std::cout << "3. Editar cliente (sincroniza con Excel)\n";
        std::cout << "4. Enviar mensaje individual\n";
        std::cout << "5. Enviar mensaje masivo\n";
        std::cout << "6. Ver plantillas de mensajes\n";
        std::cout << "7. Crear nueva plantilla\n";
        std::cout << "8. Ver historial de mensajes\n";
        std::cout << "9. Ver estadísticas\n";
        std::cout << "0. Salir\n";
        std::cout << std::string(50, '-') << std::endl;
    }

    int obtenerOpcion() {
        std::string entrada;
        int opcion;
        bool entradaValida = false;
        
        do {
            std::cout << "Seleccione una opción: ";
            std::cin >> entrada;
            if (entrada.length() == 1 && std::isdigit(entrada[0])) {
                opcion = entrada[0] - '0';
                entradaValida = true;
            } else {
                std::cout << "Error: Ingrese solo un número entre 0 y 9.\n";
            }
        } while (!entradaValida);
        
        return opcion;
    }
};

#endif
