
#ifndef ENVIOS_H
#define ENVIOS_H

#include "estructuras.h"
#include <vector>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <fstream>

class GestorEnvios {
private:
    std::vector<Cliente>& clientes;
    std::vector<Mensaje>& plantillas;
    std::vector<MensajeEnviado>& historial;

public:
    GestorEnvios(std::vector<Cliente>& _clientes, std::vector<Mensaje>& _plantillas, 
                std::vector<MensajeEnviado>& _historial)
        : clientes(_clientes), plantillas(_plantillas), historial(_historial) {}
    
    void enviarMensajeIndividual() {
        if (clientes.empty()) {
            std::cout << "\nNo hay clientes registrados para enviar mensajes.\n";
            return;
        }

        if (plantillas.empty()) {
            std::cout << "\nNo hay plantillas de mensajes disponibles.\n";
            return;
        }

        std::cout << "\n=== ENVIAR MENSAJE INDIVIDUAL ===\n";

        mostrarClientesActivos();

        int clienteId;
        std::cout << "\nIngrese el ID del cliente: ";
        std::cin >> clienteId;

        auto clienteIt = std::find_if(clientes.begin(), clientes.end(),
            [clienteId](const Cliente& c) { return c.id == clienteId && c.estado == "activo"; });

        if (clienteIt == clientes.end()) {
            std::cout << "Cliente no encontrado o inactivo.\n";
            return;
        }

        mostrarPlantillasDisponibles();
        
        int plantillaId;
        std::cout << "\nIngrese el ID de la plantilla: ";
        std::cin >> plantillaId;

        auto plantillaIt = std::find_if(plantillas.begin(), plantillas.end(),
            [plantillaId](const Mensaje& m) { return m.id == plantillaId; });

        if (plantillaIt == plantillas.end()) {
            std::cout << "Plantilla no encontrada.\n";
            return;
        }

        std::string canal = seleccionarCanal();
        if (canal.empty()) return;

        if (confirmarEnvio(*clienteIt, *plantillaIt, canal)) {
            historial.push_back(MensajeEnviado(clienteIt->id, plantillaIt->id, "enviado"));
            guardarHistorialEnCSV();
            
            std::cout << "\n✓ Mensaje enviado exitosamente!\n";
            std::cout << "✓ Canal utilizado: " << canal << "\n";
            std::cout << "✓ Datos sincronizados con Excel\n";
        }
    }

    void enviarMensajeMasivo() {
        if (clientes.empty()) {
            std::cout << "\nNo hay clientes registrados.\n";
            return;
        }

        if (plantillas.empty()) {
            std::cout << "\nNo hay plantillas disponibles.\n";
            return;
        }

        std::cout << "\n=== ENVIAR MENSAJE MASIVO ===\n";

        std::vector<Cliente*> clientesSeleccionados = seleccionarClientesMasivo();
        if (clientesSeleccionados.empty()) return;

        mostrarPlantillasDisponibles();
        
        int plantillaId;
        std::cout << "\nIngrese el ID de la plantilla: ";
        std::cin >> plantillaId;

        auto plantillaIt = std::find_if(plantillas.begin(), plantillas.end(),
            [plantillaId](const Mensaje& m) { return m.id == plantillaId; });

        if (plantillaIt == plantillas.end()) {
            std::cout << "Plantilla no encontrada.\n";
            return;
        }

        std::string canal = seleccionarCanal();
        if (canal.empty()) return;

        if (confirmarEnvioMasivo(clientesSeleccionados, *plantillaIt, canal)) {
            realizarEnvioMasivo(clientesSeleccionados, *plantillaIt, canal);
        }
    }

private:
    void mostrarClientesActivos() {
        std::cout << "\nClientes disponibles:\n";
        std::cout << std::left << std::setw(5) << "ID" << std::setw(20) << "Nombre"
                  << std::setw(15) << "Teléfono" << std::setw(10) << "Estado" << std::endl;
        std::cout << std::string(50, '-') << std::endl;
        
        for (const auto& cliente : clientes) {
            if (cliente.estado == "activo") {
                std::cout << std::left << std::setw(5) << cliente.id 
                          << std::setw(20) << cliente.nombre
                          << std::setw(15) << cliente.telefono 
                          << std::setw(10) << cliente.estado << std::endl;
            }
        }
    }

    void mostrarPlantillasDisponibles() {
        std::cout << "\nPlantillas de mensajes disponibles:\n";
        std::cout << std::left << std::setw(5) << "ID" << std::setw(15) << "Tipo"
                  << std::setw(50) << "Contenido" << std::endl;
        std::cout << std::string(70, '-') << std::endl;
        
        for (const auto& plantilla : plantillas) {
            std::string contenidoCorto = plantilla.contenido;
            if (contenidoCorto.length() > 47) {
                contenidoCorto = contenidoCorto.substr(0, 47) + "...";
            }
            
            std::cout << std::left << std::setw(5) << plantilla.id 
                      << std::setw(15) << plantilla.tipo
                      << std::setw(50) << contenidoCorto << std::endl;
        }
    }

    std::string seleccionarCanal() {
        std::cout << "\nCanales de envío disponibles:\n";
        std::cout << "1. SMS\n2. Email\n3. WhatsApp\n";
        std::cout << "Seleccione el canal (1-3): ";
        
        int canalOpcion;
        std::cin >> canalOpcion;

        switch (canalOpcion) {
            case 1: return "SMS";
            case 2: return "Email";  
            case 3: return "WhatsApp";
            default:
                std::cout << "Canal no válido.\n";
                return "";
        }
    }

    bool confirmarEnvio(const Cliente& cliente, const Mensaje& plantilla, const std::string& canal) {
        std::cout << "\n=== CONFIRMAR ENVÍO ===\n";
        std::cout << "Cliente: " << cliente.nombre << " (" << cliente.telefono << ")\n";
        std::cout << "Canal: " << canal << "\n";
        std::cout << "Mensaje: " << plantilla.contenido << "\n";
        std::cout << "\n¿Confirmar envío? (s/n): ";
        
        char confirmacion;
        std::cin >> confirmacion;
        
        return (confirmacion == 's' || confirmacion == 'S');
    }

    std::vector<Cliente*> seleccionarClientesMasivo() {
        std::vector<Cliente*> clientesSeleccionados;
        
        int clientesActivos = 0;
        for (const auto& cliente : clientes) {
            if (cliente.estado == "activo") {
                clientesActivos++;
            }
        }

        if (clientesActivos == 0) {
            std::cout << "No hay clientes activos.\n";
            return clientesSeleccionados;
        }

        std::cout << "Clientes activos encontrados: " << clientesActivos << "\n";
        std::cout << "\nOpciones de envío:\n";
        std::cout << "1. Enviar a TODOS los clientes activos\n";
        std::cout << "2. Enviar por filtro\n";
        std::cout << "Seleccione una opción (1-2): ";

        int opcion;
        std::cin >> opcion;

        if (opcion == 1) {
            for (auto& cliente : clientes) {
                if (cliente.estado == "activo") {
                    clientesSeleccionados.push_back(&cliente);
                }
            }
        } else if (opcion == 2) {
            for (auto& cliente : clientes) {
                if (cliente.estado == "activo") {
                    clientesSeleccionados.push_back(&cliente);
                }
            }
        }

        return clientesSeleccionados;
    }

    bool confirmarEnvioMasivo(const std::vector<Cliente*>& clientes, const Mensaje& plantilla, const std::string& canal) {
        std::cout << "\n=== RESUMEN DEL ENVÍO MASIVO ===\n";
        std::cout << "Destinatarios: " << clientes.size() << " clientes\n";
        std::cout << "Canal: " << canal << "\n";
        std::cout << "Plantilla: " << plantilla.tipo << "\n";
        std::cout << "Mensaje: " << plantilla.contenido.substr(0, 50) << "...\n";
        std::cout << "\n¿Confirmar envío masivo? (s/n): ";
        
        char confirmacion;
        std::cin >> confirmacion;
        
        return (confirmacion == 's' || confirmacion == 'S');
    }

    void realizarEnvioMasivo(const std::vector<Cliente*>& clientes, const Mensaje& plantilla, const std::string& canal) {
        int exitosos = 0, fallidos = 0;
        
        std::cout << "\nEnviando mensajes...\n";
        std::cout << "Progreso: [";
        
        for (size_t i = 0; i < clientes.size(); ++i) {
            std::string estado = "enviado";
            if (i % 20 == 19) estado = "fallido";
            
            historial.push_back(MensajeEnviado(clientes[i]->id, plantilla.id, estado));
            
            if (estado == "enviado") exitosos++;
            else fallidos++;
            
            if ((i + 1) % (clientes.size() / 10 + 1) == 0) {
                std::cout << "▓";
                std::cout.flush();
            }
        }
        
        std::cout << "]\n";
        
        guardarHistorialEnCSV();
        
        std::cout << "\n=== RESULTADO DEL ENVÍO MASIVO ===\n";
        std::cout << "✓ Envíos exitosos: " << exitosos << "\n";
        std::cout << "✗ Envíos fallidos: " << fallidos << "\n";
        std::cout << "📊 Tasa de éxito: " << (exitosos * 100 / clientes.size()) << "%\n";
        std::cout << "✓ Canal utilizado: " << canal << "\n";
    }

    void guardarHistorialEnCSV() {
        std::ofstream archivo("datos/historial/plantilla_historial.csv");
        if (!archivo.is_open()) {
            std::cout << "Error: No se pudo guardar el historial.\n";
            return;
        }

        archivo << "ID_Cliente,ID_Mensaje,Fecha_Envio,Estado_Envio,Canal,Observaciones\n";
        
        for (const auto& envio : historial) {
            std::tm* timeinfo = std::localtime(&envio.fechaEnvio);
            
            std::string canal = "SMS";
            std::string observaciones = (envio.estado == "fallido") ? "Error en el envío" : "Enviado correctamente";
            
            archivo << envio.clienteId << ","
                   << envio.mensajeId << ","
                   << (timeinfo->tm_year + 1900) << "-"
                   << std::setfill('0') << std::setw(2) << (timeinfo->tm_mon + 1) << "-"
                   << std::setfill('0') << std::setw(2) << timeinfo->tm_mday << " "
                   << std::setfill('0') << std::setw(2) << timeinfo->tm_hour << ":"
                   << std::setfill('0') << std::setw(2) << timeinfo->tm_min << ","
                   << envio.estado << ","
                   << canal << ","
                   << observaciones << "\n";
        }
        
        archivo.close();
    }
};

#endif
