
#ifndef CLIENTES_H
#define CLIENTES_H

#include "estructuras.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <ctime>

class GestorClientes {
private:
    std::vector<Cliente>& clientes;
    int& proximoIdCliente;

public:
    GestorClientes(std::vector<Cliente>& _clientes, int& _proximoIdCliente) 
        : clientes(_clientes), proximoIdCliente(_proximoIdCliente) {}
    
    void cargarClientesDesdeCSV() {
        std::ifstream archivo("datos/clientes/plantilla_clientes.csv");
        if (!archivo.is_open()) {
            std::cout << "Archivo de clientes no encontrado, se creará uno nuevo.\n";
            return;
        }

        std::string linea;
        bool primeraLinea = true;
        
        while (std::getline(archivo, linea)) {
            if (primeraLinea) {
                primeraLinea = false;
                continue;
            }
            
            if (linea.empty()) continue;
            
            std::stringstream ss(linea);
            std::string campo;
            std::vector<std::string> campos;
            
            while (std::getline(ss, campo, ',')) {
                campos.push_back(campo);
            }
            
            if (campos.size() >= 5 && !campos[0].empty()) {
                try {
                    int id = std::stoi(campos[0]);
                    clientes.push_back(Cliente(id, campos[1], campos[2], campos[3]));
                    clientes.back().estado = campos[4];
                    
                    if (id >= proximoIdCliente) {
                        proximoIdCliente = id + 1;
                    }
                } catch (const std::invalid_argument& e) {
                    std::cout << "Error: ID inválido en línea del CSV, saltando línea.\n";
                    continue;
                } catch (const std::out_of_range& e) {
                    std::cout << "Error: ID fuera de rango en línea del CSV, saltando línea.\n";
                    continue;
                }
            }
        }
        archivo.close();
    }

    void guardarClientesEnCSV() {
        std::ofstream archivo("datos/clientes/plantilla_clientes.csv");
        if (!archivo.is_open()) {
            std::cout << "Error: No se pudo abrir el archivo para escritura.\n";
            return;
        }

        archivo << "ID,Nombre,Telefono,Email,Estado,Fecha_Registro\n";
        
        for (const auto& cliente : clientes) {
            std::time_t now = std::time(nullptr);
            std::tm* timeinfo = std::localtime(&now);
            
            archivo << cliente.id << ","
                   << cliente.nombre << ","
                   << cliente.telefono << ","
                   << cliente.email << ","
                   << cliente.estado << ","
                   << (timeinfo->tm_year + 1900) << "-"
                   << std::setfill('0') << std::setw(2) << (timeinfo->tm_mon + 1) << "-"
                   << std::setfill('0') << std::setw(2) << timeinfo->tm_mday << "\n";
        }
        
        archivo.close();
    }

    void agregarCliente() {
        std::string nombre, telefono, email;
        std::cout << "\n=== AGREGAR NUEVO CLIENTE ===\n";
        std::cout << "Nombre: ";
        std::cin.ignore();
        std::getline(std::cin, nombre);

        do {
            std::cout << "Teléfono (10 dígitos): ";
            std::getline(std::cin, telefono);
            if (telefono.length() != 10 || !std::all_of(telefono.begin(), telefono.end(), ::isdigit)) {
                std::cout << "Error: El teléfono debe contener exactamente 10 números.\n";
            } else {
                break;
            }
        } while (true);

        std::cout << "Email: ";
        std::getline(std::cin, email);

        clientes.push_back(Cliente(proximoIdCliente++, nombre, telefono, email));
        guardarClientesEnCSV();
        std::cout << "\n✓ Cliente agregado exitosamente con ID: " << (proximoIdCliente - 1) << std::endl;
        std::cout << "✓ Datos sincronizados con Excel en: datos/clientes/plantilla_clientes.csv" << std::endl;
    }

    void editarCliente() {
        if (clientes.empty()) {
            std::cout << "No hay clientes registrados.\n";
            return;
        }

        listarClientes();

        int clienteId;
        std::cout << "\nIngrese el ID del cliente a editar: ";
        std::cin >> clienteId;
        std::cin.ignore();

        auto clienteIt = std::find_if(clientes.begin(), clientes.end(),
            [clienteId](const Cliente& c) { return c.id == clienteId; });

        if (clienteIt == clientes.end()) {
            std::cout << "Cliente no encontrado.\n";
            return;
        }

        std::string nuevoValor;
        int opcion;
        std::cout << "\n=== EDITAR CLIENTE ===\n";
        std::cout << "1. Nombre\n2. Teléfono\n3. Email\n4. Estado\n5. Editar todo\nSeleccione una opción: ";
        std::cin >> opcion;
        std::cin.ignore();

        switch (opcion) {
            case 1:
                std::cout << "Nuevo nombre: ";
                std::getline(std::cin, clienteIt->nombre);
                break;
            case 2:
                do {
                    std::cout << "Nuevo teléfono (10 dígitos): ";
                    std::getline(std::cin, nuevoValor);
                    if (nuevoValor.length() != 10 || !std::all_of(nuevoValor.begin(), nuevoValor.end(), ::isdigit)) {
                        std::cout << "Error: El teléfono debe contener exactamente 10 números.\n";
                    } else {
                        clienteIt->telefono = nuevoValor;
                        break;
                    }
                } while (true);
                break;
            case 3:
                std::cout << "Nuevo email: ";
                std::getline(std::cin, clienteIt->email);
                break;
            case 4:
                std::cout << "Nuevo estado (activo/inactivo): ";
                std::getline(std::cin, nuevoValor);
                if (nuevoValor == "activo" || nuevoValor == "inactivo") {
                    clienteIt->estado = nuevoValor;
                } else {
                    std::cout << "Estado inválido.\n";
                }
                break;
            case 5:
                std::cout << "Nuevo nombre: ";
                std::getline(std::cin, clienteIt->nombre);
                do {
                    std::cout << "Nuevo teléfono (10 dígitos): ";
                    std::getline(std::cin, clienteIt->telefono);
                    if (clienteIt->telefono.length() != 10 || !std::all_of(clienteIt->telefono.begin(), clienteIt->telefono.end(), ::isdigit)) {
                        std::cout << "Error: El teléfono debe contener exactamente 10 números.\n";
                    } else {
                        break;
                    }
                } while (true);
                std::cout << "Nuevo email: ";
                std::getline(std::cin, clienteIt->email);
                std::cout << "Nuevo estado (activo/inactivo): ";
                std::getline(std::cin, nuevoValor);
                if (nuevoValor == "activo" || nuevoValor == "inactivo") {
                    clienteIt->estado = nuevoValor;
                }
                break;
            default:
                std::cout << "Opción no válida.\n";
                return;
        }
        
        guardarClientesEnCSV();
        std::cout << "\n✓ Datos actualizados exitosamente.\n";
        std::cout << "✓ Cambios sincronizados con Excel en: datos/clientes/plantilla_clientes.csv" << std::endl;
    }

    void listarClientes() {
        std::cout << "\n=== LISTA DE CLIENTES ===\n";
        if (clientes.empty()) {
            std::cout << "No hay clientes registrados.\n";
            return;
        }
        
        std::cout << std::left << std::setw(5) << "ID" << std::setw(20) << "Nombre"
                  << std::setw(15) << "Teléfono" << std::setw(25) << "Email"
                  << std::setw(10) << "Estado" << std::endl;
                  
        for (const auto& cliente : clientes) {
            std::cout << std::left << std::setw(5) << cliente.id << std::setw(20) << cliente.nombre
                      << std::setw(15) << cliente.telefono << std::setw(25) << cliente.email
                      << std::setw(10) << cliente.estado << std::endl;
        }
    }
};

#endif
