
#ifndef SISTEMA_H
#define SISTEMA_H

#include "estructuras.h"
#include "menu.h"
#include "clientes.h"
#include "mensajes.h"
#include "envios.h"
#include "historial.h"
#include "estadisticas.h"
#include <vector>
#include <iostream>

class SistemaMensajeria {
private:
    std::vector<Cliente> clientes;
    std::vector<Mensaje> plantillas;
    std::vector<MensajeEnviado> historial;
    int proximoIdCliente;
    int proximoIdMensaje;
    
    MenuSistema* menuSistema;
    GestorClientes* gestorClientes;
    GestorMensajes* gestorMensajes;
    GestorEnvios* gestorEnvios;
    GestorHistorial* gestorHistorial;
    GestorEstadisticas* gestorEstadisticas;

public:
    SistemaMensajeria() : proximoIdCliente(1), proximoIdMensaje(1) {
        gestorClientes = new GestorClientes(clientes, proximoIdCliente);
        gestorMensajes = new GestorMensajes(plantillas, proximoIdMensaje);
        gestorEnvios = new GestorEnvios(clientes, plantillas, historial);
        gestorHistorial = new GestorHistorial(clientes, plantillas, historial);
        gestorEstadisticas = new GestorEstadisticas(clientes, plantillas, historial);
        menuSistema = new MenuSistema();
        
        inicializar();
    }

    ~SistemaMensajeria() {
        delete gestorClientes;
        delete gestorMensajes;
        delete gestorEnvios;
        delete gestorHistorial;
        delete gestorEstadisticas;
        delete menuSistema;
    }
    
    void ejecutar() {
        std::cout << "Iniciando Sistema de Mensajería Automática para Clientes...\n";
        
        if (!menuSistema->iniciarSesion()) return;

        int opcion;
        do {
            menuSistema->mostrarMenuPrincipal();
            opcion = menuSistema->obtenerOpcion();

            switch (opcion) {
                case 1: 
                    gestorClientes->agregarCliente(); 
                    break;
                case 2: 
                    gestorClientes->listarClientes(); 
                    break;
                case 3: 
                    gestorClientes->editarCliente(); 
                    break;
                case 4: 
                    gestorEnvios->enviarMensajeIndividual(); 
                    break;
                case 5: 
                    gestorEnvios->enviarMensajeMasivo(); 
                    break;
                case 6: 
                    gestorMensajes->verPlantillasMensajes(); 
                    break;
                case 7: 
                    gestorMensajes->crearNuevaPlantilla(); 
                    break;
                case 8: 
                    gestorHistorial->verHistorialMensajes(); 
                    break;
                case 9: 
                    gestorEstadisticas->verEstadisticas(); 
                    break;
                case 0:
                    std::cout << "¡Gracias por usar el sistema de mensajería!\n";
                    break;
                default:
                    std::cout << "Opción no válida. Seleccione entre 0 y 9.\n";
            }
            
            if (opcion != 0) {
                std::cout << "\nPresione Enter para continuar...";
                std::cin.ignore();
                std::cin.get();
            }
        } while (opcion != 0);
    }

private:
    void inicializar() {
        plantillas.push_back(Mensaje(proximoIdMensaje++, "¡Bienvenido a nuestros servicios! Gracias por confiar en nosotros.", "bienvenida"));
        plantillas.push_back(Mensaje(proximoIdMensaje++, "¡Oferta especial! 20% de descuento en todos nuestros productos. ¡No te lo pierdas!", "promocional"));
        plantillas.push_back(Mensaje(proximoIdMensaje++, "Recordatorio: Tienes una cita pendiente con nosotros. ¡Te esperamos!", "recordatorio"));
        plantillas.push_back(Mensaje(proximoIdMensaje++, "Gracias por tu compra. Tu pedido está siendo procesado.", "confirmacion"));
        
        gestorClientes->cargarClientesDesdeCSV();
        gestorMensajes->cargarPlantillasDesdeCSV();
        gestorHistorial->cargarHistorialDesdeCSV();
    }
};

#endif
