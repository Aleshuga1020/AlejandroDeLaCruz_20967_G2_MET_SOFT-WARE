
#ifndef HISTORIAL_H
#define HISTORIAL_H

#include "estructuras.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <ctime>

class GestorHistorial {
private:
    std::vector<Cliente>& clientes;
    std::vector<Mensaje>& plantillas;
    std::vector<MensajeEnviado>& historial;

public:
    GestorHistorial(std::vector<Cliente>& _clientes, std::vector<Mensaje>& _plantillas, 
                   std::vector<MensajeEnviado>& _historial)
        : clientes(_clientes), plantillas(_plantillas), historial(_historial) {}
    
    void cargarHistorialDesdeCSV() {
        std::ifstream archivo("datos/historial/plantilla_historial.csv");
        if (!archivo.is_open()) {
            std::cout << "Archivo de historial no encontrado, se creará uno nuevo al enviar mensajes.\n";
            return;
        }

        std::string linea;
        bool primeraLinea = true;
        
        while (std::getline(archivo, linea)) {
            if (primeraLinea) {
                primeraLinea = false;
                continue;
            }
            
            if (linea.empty()) continue;
            
            std::stringstream ss(linea);
            std::string campo;
            std::vector<std::string> campos;
            
            while (std::getline(ss, campo, ',')) {
                campos.push_back(campo);
            }
            
            if (campos.size() >= 4 && !campos[0].empty()) {
                try {
                    int clienteId = std::stoi(campos[0]);
                    int mensajeId = std::stoi(campos[1]);
                    std::string estado = campos[3];
                    
                    historial.push_back(MensajeEnviado(clienteId, mensajeId, estado));
                } catch (const std::invalid_argument& e) {
                    std::cout << "Error: Datos inválidos en línea del historial, saltando línea.\n";
                    continue;
                } catch (const std::out_of_range& e) {
                    std::cout << "Error: Datos fuera de rango en línea del historial, saltando línea.\n";
                    continue;
                }
            }
        }
        archivo.close();
    }

    void verHistorialMensajes() {
        std::cout << "\n=== HISTORIAL DE MENSAJES ENVIADOS ===\n";
        
        if (historial.empty()) {
            std::cout << "No hay mensajes en el historial.\n";
            return;
        }

        std::cout << "\nOpciones de visualización:\n";
        std::cout << "1. Ver todos los mensajes\n";
        std::cout << "2. Filtrar por estado (enviado/fallido)\n";
        std::cout << "3. Filtrar por cliente\n";
        std::cout << "4. Filtrar por fecha\n";
        std::cout << "5. Exportar historial completo\n";
        std::cout << "Seleccione una opción (1-5): ";

        int opcion;
        std::cin >> opcion;

        std::vector<MensajeEnviado> mensajesFiltrados;

        switch (opcion) {
            case 1:
                mensajesFiltrados = historial;
                break;
            case 2:
                filtrarPorEstado(mensajesFiltrados);
                break;
            case 3:
                filtrarPorCliente(mensajesFiltrados);
                break;
            case 4:
                filtrarPorFecha(mensajesFiltrados);
                break;
            case 5:
                exportarHistorialCompleto();
                return;
            default:
                std::cout << "Opción no válida.\n";
                return;
        }

        if (mensajesFiltrados.empty()) {
            std::cout << "No se encontraron mensajes con los criterios especificados.\n";
            return;
        }

        mostrarHistorial(mensajesFiltrados);
    }

private:
    void filtrarPorEstado(std::vector<MensajeEnviado>& mensajesFiltrados) {
        std::cout << "\nFiltrar por estado:\n";
        std::cout << "1. Solo enviados\n";
        std::cout << "2. Solo fallidos\n";
        std::cout << "Seleccione: ";
        
        int filtro;
        std::cin >> filtro;
        
        std::string estadoBuscado = (filtro == 1) ? "enviado" : "fallido";
        
        for (const auto& mensaje : historial) {
            if (mensaje.estado == estadoBuscado) {
                mensajesFiltrados.push_back(mensaje);
            }
        }
    }

    void filtrarPorCliente(std::vector<MensajeEnviado>& mensajesFiltrados) {
        if (clientes.empty()) {
            std::cout << "No hay clientes registrados.\n";
            return;
        }

        std::cout << "\nClientes disponibles:\n";
        for (const auto& cliente : clientes) {
            std::cout << cliente.id << ". " << cliente.nombre << std::endl;
        }

        std::cout << "Ingrese el ID del cliente: ";
        int clienteId;
        std::cin >> clienteId;

        for (const auto& mensaje : historial) {
            if (mensaje.clienteId == clienteId) {
                mensajesFiltrados.push_back(mensaje);
            }
        }
    }

    void filtrarPorFecha(std::vector<MensajeEnviado>& mensajesFiltrados) {
        std::cout << "\nFiltrar mensajes de hoy? (s/n): ";
        char opcion;
        std::cin >> opcion;
        
        std::time_t ahora = std::time(nullptr);
        std::tm* hoy = std::localtime(&ahora);
        
        for (const auto& mensaje : historial) {
            std::tm* fechaMensaje = std::localtime(&mensaje.fechaEnvio);
            
            if (opcion == 's' || opcion == 'S') {
                if (fechaMensaje->tm_year == hoy->tm_year &&
                    fechaMensaje->tm_mon == hoy->tm_mon &&
                    fechaMensaje->tm_mday == hoy->tm_mday) {
                    mensajesFiltrados.push_back(mensaje);
                }
            } else {
                mensajesFiltrados.push_back(mensaje);
            }
        }
    }

    void mostrarHistorial(const std::vector<MensajeEnviado>& mensajes) {
        std::cout << "\n" << std::string(100, '=') << std::endl;
        std::cout << std::left << std::setw(12) << "Fecha/Hora" 
                  << std::setw(20) << "Cliente" 
                  << std::setw(15) << "Teléfono"
                  << std::setw(35) << "Mensaje" 
                  << std::setw(10) << "Estado" << std::endl;
        std::cout << std::string(100, '-') << std::endl;

        for (const auto& envio : mensajes) {
            std::string nombreCliente = "Cliente no encontrado";
            std::string telefonoCliente = "N/A";
            
            auto clienteIt = std::find_if(clientes.begin(), clientes.end(),
                [&envio](const Cliente& c) { return c.id == envio.clienteId; });
            
            if (clienteIt != clientes.end()) {
                nombreCliente = clienteIt->nombre;
                telefonoCliente = clienteIt->telefono;
                if (nombreCliente.length() > 18) {
                    nombreCliente = nombreCliente.substr(0, 18) + "..";
                }
            }

            std::string contenidoMensaje = "Mensaje no encontrado";
            auto mensajeIt = std::find_if(plantillas.begin(), plantillas.end(),
                [&envio](const Mensaje& m) { return m.id == envio.mensajeId; });
            
            if (mensajeIt != plantillas.end()) {
                contenidoMensaje = mensajeIt->contenido;
                if (contenidoMensaje.length() > 32) {
                    contenidoMensaje = contenidoMensaje.substr(0, 32) + "...";
                }
            }

            std::tm* timeinfo = std::localtime(&envio.fechaEnvio);
            std::ostringstream fechaStr;
            fechaStr << std::setfill('0') << std::setw(2) << timeinfo->tm_mday << "/"
                     << std::setfill('0') << std::setw(2) << (timeinfo->tm_mon + 1) << " "
                     << std::setfill('0') << std::setw(2) << timeinfo->tm_hour << ":"
                     << std::setfill('0') << std::setw(2) << timeinfo->tm_min;

            std::cout << std::left << std::setw(12) << fechaStr.str()
                      << std::setw(20) << nombreCliente
                      << std::setw(15) << telefonoCliente
                      << std::setw(35) << contenidoMensaje
                      << std::setw(10) << envio.estado << std::endl;
        }
        
        std::cout << std::string(100, '=') << std::endl;
        std::cout << "Total de mensajes mostrados: " << mensajes.size() << std::endl;
    }

    void exportarHistorialCompleto() {
        std::cout << "\n=== EXPORTAR HISTORIAL COMPLETO ===\n";
        
        std::string nombreArchivo = "datos/historial/reporte_historial_detallado.csv";
        std::ofstream archivo(nombreArchivo);
        
        if (!archivo.is_open()) {
            std::cout << "Error: No se pudo crear el archivo de reporte.\n";
            return;
        }

        archivo << "Fecha_Envio,Hora_Envio,ID_Cliente,Nombre_Cliente,Telefono_Cliente,Email_Cliente,"
                << "ID_Mensaje,Tipo_Mensaje,Contenido_Mensaje,Estado_Envio,Canal,Observaciones\n";
        
        for (const auto& envio : historial) {
            std::tm* timeinfo = std::localtime(&envio.fechaEnvio);
            
            std::string nombreCliente = "", telefonoCliente = "", emailCliente = "";
            auto clienteIt = std::find_if(clientes.begin(), clientes.end(),
                [&envio](const Cliente& c) { return c.id == envio.clienteId; });
            
            if (clienteIt != clientes.end()) {
                nombreCliente = clienteIt->nombre;
                telefonoCliente = clienteIt->telefono;
                emailCliente = clienteIt->email;
            }

            std::string tipoMensaje = "", contenidoMensaje = "";
            auto mensajeIt = std::find_if(plantillas.begin(), plantillas.end(),
                [&envio](const Mensaje& m) { return m.id == envio.mensajeId; });
            
            if (mensajeIt != plantillas.end()) {
                tipoMensaje = mensajeIt->tipo;
                contenidoMensaje = mensajeIt->contenido;
                size_t pos = 0;
                while ((pos = contenidoMensaje.find("\"", pos)) != std::string::npos) {
                    contenidoMensaje.replace(pos, 1, "\"\"");
                    pos += 2;
                }
            }

            archivo << (timeinfo->tm_year + 1900) << "-"
                   << std::setfill('0') << std::setw(2) << (timeinfo->tm_mon + 1) << "-"
                   << std::setfill('0') << std::setw(2) << timeinfo->tm_mday << ","
                   << std::setfill('0') << std::setw(2) << timeinfo->tm_hour << ":"
                   << std::setfill('0') << std::setw(2) << timeinfo->tm_min << ","
                   << envio.clienteId << ","
                   << nombreCliente << ","
                   << telefonoCliente << ","
                   << emailCliente << ","
                   << envio.mensajeId << ","
                   << tipoMensaje << ",\""
                   << contenidoMensaje << "\","
                   << envio.estado << ","
                   << "SMS,"
                   << (envio.estado == "enviado" ? "Enviado correctamente" : "Error en el envío") << "\n";
        }
        
        archivo.close();
        
        std::cout << "✓ Reporte detallado exportado exitosamente!\n";
        std::cout << "✓ Archivo guardado en: " << nombreArchivo << "\n";
        std::cout << "✓ Total de registros: " << historial.size() << "\n";
    }
};

#endif
