
package services;

import models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class EstadisticaService {

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private MensajeService mensajeService;

    @Autowired
    private EnvioService envioService;

    public Map<String, Object> obtenerEstadisticasGenerales() {
        List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
        List<Mensaje> mensajes = mensajeService.obtenerTodasLasPlantillas();
        List<MensajeEnviado> historial = envioService.obtenerHistorial();

        Map<String, Object> stats = new HashMap<>();
        
        long clientesActivos = clientes.stream().filter(c -> "activo".equals(c.getEstado())).count();
        long mensajesExitosos = historial.stream().filter(h -> "enviado".equals(h.getEstado())).count();
        long mensajesFallidos = historial.stream().filter(h -> "fallido".equals(h.getEstado())).count();
        
        stats.put("totalClientes", clientes.size());
        stats.put("clientesActivos", clientesActivos);
        stats.put("clientesInactivos", clientes.size() - clientesActivos);
        stats.put("totalPlantillas", mensajes.size());
        stats.put("totalMensajes", historial.size());
        stats.put("mensajesExitosos", mensajesExitosos);
        stats.put("mensajesFallidos", mensajesFallidos);
        
        if (historial.size() > 0) {
            double tasaExito = (mensajesExitosos * 100.0) / historial.size();
            stats.put("tasaExito", Math.round(tasaExito * 100.0) / 100.0);
        } else {
            stats.put("tasaExito", 0.0);
        }

        return stats;
    }

    public Map<String, Object> obtenerEstadisticasCompletas() {
        Map<String, Object> stats = obtenerEstadisticasGenerales();
        
        List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
        List<Mensaje> mensajes = mensajeService.obtenerTodasLasPlantillas();
        List<MensajeEnviado> historial = envioService.obtenerHistorial();

        // Estadísticas por tipo de mensaje
        Map<String, Long> mensajesPorTipo = new HashMap<>();
        for (Mensaje mensaje : mensajes) {
            mensajesPorTipo.put(mensaje.getTipo(), 
                mensajesPorTipo.getOrDefault(mensaje.getTipo(), 0L) + 1);
        }
        stats.put("mensajesPorTipo", mensajesPorTipo);

        // Dominios de email más comunes
        Map<String, Long> dominios = clientes.stream()
            .filter(c -> c.getEmail() != null && c.getEmail().contains("@"))
            .collect(Collectors.groupingBy(
                c -> c.getEmail().substring(c.getEmail().indexOf("@") + 1),
                Collectors.counting()
            ));
        stats.put("dominiosComunes", dominios);

        // Mensajes enviados hoy
        LocalDateTime hoy = LocalDateTime.now();
        long mensajesHoy = historial.stream()
            .filter(h -> h.getFechaEnvio().toLocalDate().equals(hoy.toLocalDate()))
            .count();
        stats.put("mensajesHoy", mensajesHoy);

        return stats;
    }
}
