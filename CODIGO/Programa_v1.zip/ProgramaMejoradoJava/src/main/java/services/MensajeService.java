
package services;

import models.Mensaje;
import org.springframework.stereotype.Service;
import com.opencsv.*;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class MensajeService {
    private final String CSV_FILE = "datos/mensajes/plantilla_mensajes.csv";
    private List<Mensaje> plantillas = new ArrayList<>();
    private AtomicInteger proximoId = new AtomicInteger(1);

    public MensajeService() {
        crearDirectorioSiNoExiste();
        inicializarPlantillasDefault();
        cargarPlantillasDesdeCSV();
    }

    private void crearDirectorioSiNoExiste() {
        try {
            Files.createDirectories(Paths.get("datos/mensajes"));
        } catch (Exception e) {
            System.err.println("Error creando directorio: " + e.getMessage());
        }
    }

    private void inicializarPlantillasDefault() {
        plantillas.add(new Mensaje(proximoId.getAndIncrement(), "¡Bienvenido a nuestros servicios! Gracias por confiar en nosotros.", "bienvenida"));
        plantillas.add(new Mensaje(proximoId.getAndIncrement(), "¡Oferta especial! 20% de descuento en todos nuestros productos. ¡No te lo pierdas!", "promocional"));
        plantillas.add(new Mensaje(proximoId.getAndIncrement(), "Recordatorio: Tienes una cita pendiente con nosotros. ¡Te esperamos!", "recordatorio"));
        plantillas.add(new Mensaje(proximoId.getAndIncrement(), "Gracias por tu compra. Tu pedido está siendo procesado.", "confirmacion"));
    }

    public void cargarPlantillasDesdeCSV() {
        try {
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                guardarPlantillasEnCSV();
                return;
            }

            List<Mensaje> plantillasCSV = new ArrayList<>();
            try (CSVReader reader = new CSVReader(new FileReader(file))) {
                List<String[]> records = reader.readAll();
                if (records.size() > 1) { // Skip header
                    for (int i = 1; i < records.size(); i++) {
                        String[] record = records.get(i);
                        if (record.length >= 3 && !record[0].trim().isEmpty()) {
                            Mensaje mensaje = new Mensaje();
                            mensaje.setId(Integer.parseInt(record[0]));
                            mensaje.setContenido(record[1]);
                            mensaje.setTipo(record[2]);
                            plantillasCSV.add(mensaje);
                            
                            if (mensaje.getId() >= proximoId.get()) {
                                proximoId.set(mensaje.getId() + 1);
                            }
                        }
                    }
                }
            }
            if (!plantillasCSV.isEmpty()) {
                plantillas = plantillasCSV;
            }
        } catch (Exception e) {
            System.err.println("Error cargando plantillas: " + e.getMessage());
        }
    }

    public void guardarPlantillasEnCSV() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID", "Contenido", "Tipo", "Fecha_Creacion", "Activo"};
            writer.writeNext(header);
            
            for (Mensaje mensaje : plantillas) {
                String[] record = {
                    String.valueOf(mensaje.getId()),
                    mensaje.getContenido(),
                    mensaje.getTipo(),
                    mensaje.getFechaCreacion().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                    "si"
                };
                writer.writeNext(record);
            }
        } catch (Exception e) {
            System.err.println("Error guardando plantillas: " + e.getMessage());
        }
    }

    public void crearPlantilla(Mensaje mensaje) {
        mensaje.setId(proximoId.getAndIncrement());
        mensaje.setFechaCreacion(LocalDateTime.now());
        plantillas.add(mensaje);
        guardarPlantillasEnCSV();
    }

    public List<Mensaje> obtenerTodasLasPlantillas() {
        return new ArrayList<>(plantillas);
    }

    public Mensaje obtenerPlantillaPorId(int id) {
        return plantillas.stream()
                .filter(m -> m.getId() == id)
                .findFirst()
                .orElse(null);
    }
}
