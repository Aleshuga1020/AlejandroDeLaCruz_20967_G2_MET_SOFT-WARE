
package services;

import models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.opencsv.*;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class EnvioService {
    private final String CSV_FILE = "datos/historial/plantilla_historial.csv";
    private List<MensajeEnviado> historial = new ArrayList<>();

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private MensajeService mensajeService;

    public EnvioService() {
        crearDirectorioSiNoExiste();
        cargarHistorialDesdeCSV();
    }

    private void crearDirectorioSiNoExiste() {
        try {
            Files.createDirectories(Paths.get("datos/historial"));
        } catch (Exception e) {
            System.err.println("Error creando directorio: " + e.getMessage());
        }
    }

    public void cargarHistorialDesdeCSV() {
        try {
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                crearArchivoCSVVacio();
                return;
            }

            try (CSVReader reader = new CSVReader(new FileReader(file))) {
                List<String[]> records = reader.readAll();
                if (records.size() > 1) { // Skip header
                    for (int i = 1; i < records.size(); i++) {
                        String[] record = records.get(i);
                        if (record.length >= 4 && !record[0].trim().isEmpty()) {
                            MensajeEnviado envio = new MensajeEnviado();
                            envio.setClienteId(Integer.parseInt(record[0]));
                            envio.setMensajeId(Integer.parseInt(record[1]));
                            envio.setEstado(record[3]);
                            if (record.length >= 5) {
                                envio.setCanal(record[4]);
                            }
                            historial.add(envio);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error cargando historial: " + e.getMessage());
        }
    }

    private void crearArchivoCSVVacio() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID_Cliente", "ID_Mensaje", "Fecha_Envio", "Estado_Envio", "Canal", "Observaciones"};
            writer.writeNext(header);
        } catch (Exception e) {
            System.err.println("Error creando archivo CSV: " + e.getMessage());
        }
    }

    public void guardarHistorialEnCSV() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID_Cliente", "ID_Mensaje", "Fecha_Envio", "Estado_Envio", "Canal", "Observaciones"};
            writer.writeNext(header);
            
            for (MensajeEnviado envio : historial) {
                String[] record = {
                    String.valueOf(envio.getClienteId()),
                    String.valueOf(envio.getMensajeId()),
                    envio.getFechaEnvio().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                    envio.getEstado(),
                    envio.getCanal() != null ? envio.getCanal() : "SMS",
                    "enviado".equals(envio.getEstado()) ? "Enviado correctamente" : "Error en el envío"
                };
                writer.writeNext(record);
            }
        } catch (Exception e) {
            System.err.println("Error guardando historial: " + e.getMessage());
        }
    }

    public void enviarMensajeIndividual(int clienteId, int mensajeId, String canal) {
        Cliente cliente = clienteService.obtenerClientePorId(clienteId);
        Mensaje mensaje = mensajeService.obtenerPlantillaPorId(mensajeId);
        
        if (cliente == null || !"activo".equals(cliente.getEstado())) {
            throw new IllegalArgumentException("Cliente no encontrado o inactivo");
        }
        
        if (mensaje == null) {
            throw new IllegalArgumentException("Plantilla no encontrada");
        }

        // Simular envío
        String estado = "enviado";
        
        MensajeEnviado envio = new MensajeEnviado(clienteId, mensajeId, estado, canal);
        historial.add(envio);
        guardarHistorialEnCSV();
    }

    public Map<String, Integer> enviarMensajeMasivo(int mensajeId, String canal) {
        List<Cliente> clientesActivos = clienteService.obtenerClientesActivos();
        Mensaje mensaje = mensajeService.obtenerPlantillaPorId(mensajeId);
        
        if (mensaje == null) {
            throw new IllegalArgumentException("Plantilla no encontrada");
        }
        
        if (clientesActivos.isEmpty()) {
            throw new IllegalArgumentException("No hay clientes activos");
        }

        int exitosos = 0;
        int fallidos = 0;

        for (int i = 0; i < clientesActivos.size(); i++) {
            Cliente cliente = clientesActivos.get(i);
            // Simular algunos fallos (cada 20 envíos)
            String estado = (i % 20 == 19) ? "fallido" : "enviado";
            
            if ("enviado".equals(estado)) {
                exitosos++;
            } else {
                fallidos++;
            }
            
            MensajeEnviado envio = new MensajeEnviado(cliente.getId(), mensajeId, estado, canal);
            historial.add(envio);
        }

        guardarHistorialEnCSV();
        
        Map<String, Integer> resultado = new HashMap<>();
        resultado.put("exitosos", exitosos);
        resultado.put("fallidos", fallidos);
        resultado.put("total", clientesActivos.size());
        
        return resultado;
    }

    public List<MensajeEnviado> obtenerHistorial() {
        return new ArrayList<>(historial);
    }
}
