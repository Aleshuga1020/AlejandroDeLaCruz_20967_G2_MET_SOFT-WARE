
package services;

import models.Cliente;
import org.springframework.stereotype.Service;
import com.opencsv.*;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class ClienteService {
    private final String CSV_FILE = "datos/clientes/plantilla_clientes.csv";
    private List<Cliente> clientes = new ArrayList<>();
    private AtomicInteger proximoId = new AtomicInteger(1);

    public ClienteService() {
        crearDirectorioSiNoExiste();
        cargarClientesDesdeCSV();
    }

    private void crearDirectorioSiNoExiste() {
        try {
            Files.createDirectories(Paths.get("datos/clientes"));
        } catch (Exception e) {
            System.err.println("Error creando directorio: " + e.getMessage());
        }
    }

    public void cargarClientesDesdeCSV() {
        try {
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                crearArchivoCSVVacio();
                return;
            }

            try (CSVReader reader = new CSVReader(new FileReader(file))) {
                List<String[]> records = reader.readAll();
                if (records.size() > 1) { // Skip header
                    for (int i = 1; i < records.size(); i++) {
                        String[] record = records.get(i);
                        if (record.length >= 5 && !record[0].trim().isEmpty()) {
                            Cliente cliente = new Cliente();
                            cliente.setId(Integer.parseInt(record[0]));
                            cliente.setNombre(record[1]);
                            cliente.setTelefono(record[2]);
                            cliente.setEmail(record[3]);
                            cliente.setEstado(record[4]);
                            clientes.add(cliente);
                            
                            if (cliente.getId() >= proximoId.get()) {
                                proximoId.set(cliente.getId() + 1);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error cargando clientes: " + e.getMessage());
        }
    }

    private void crearArchivoCSVVacio() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID", "Nombre", "Telefono", "Email", "Estado", "Fecha_Registro"};
            writer.writeNext(header);
        } catch (Exception e) {
            System.err.println("Error creando archivo CSV: " + e.getMessage());
        }
    }

    public void guardarClientesEnCSV() {
        try (CSVWriter writer = new CSVWriter(new FileWriter(CSV_FILE))) {
            String[] header = {"ID", "Nombre", "Telefono", "Email", "Estado", "Fecha_Registro"};
            writer.writeNext(header);
            
            for (Cliente cliente : clientes) {
                String[] record = {
                    String.valueOf(cliente.getId()),
                    cliente.getNombre(),
                    cliente.getTelefono(),
                    cliente.getEmail(),
                    cliente.getEstado(),
                    cliente.getFechaRegistro().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                };
                writer.writeNext(record);
            }
        } catch (Exception e) {
            System.err.println("Error guardando clientes: " + e.getMessage());
        }
    }

    public void agregarCliente(Cliente cliente) {
        if (!validarTelefono(cliente.getTelefono())) {
            throw new IllegalArgumentException("El teléfono debe tener exactamente 10 dígitos");
        }
        cliente.setId(proximoId.getAndIncrement());
        cliente.setFechaRegistro(LocalDateTime.now());
        clientes.add(cliente);
        guardarClientesEnCSV();
    }

    public void actualizarCliente(Cliente clienteActualizado) {
        if (!validarTelefono(clienteActualizado.getTelefono())) {
            throw new IllegalArgumentException("El teléfono debe tener exactamente 10 dígitos");
        }
        
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getId() == clienteActualizado.getId()) {
                clientes.set(i, clienteActualizado);
                guardarClientesEnCSV();
                return;
            }
        }
        throw new IllegalArgumentException("Cliente no encontrado");
    }

    private boolean validarTelefono(String telefono) {
        return telefono != null && telefono.matches("\\d{10}");
    }

    public List<Cliente> obtenerTodosLosClientes() {
        return new ArrayList<>(clientes);
    }

    public List<Cliente> obtenerClientesActivos() {
        return clientes.stream()
                .filter(c -> "activo".equals(c.getEstado()))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public Cliente obtenerClientePorId(int id) {
        return clientes.stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(null);
    }
}
