package controllers;

import models.*;
import services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

@Controller
public class WebController {

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private MensajeService mensajeService;

    @Autowired
    private EnvioService envioService;

    @Autowired
    private EstadisticaService estadisticaService;

    @GetMapping("/")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam String usuario, 
                              @RequestParam String contrasena, 
                              Model model) {
        if ("administrador".equals(usuario) && "administrador001".equals(contrasena)) {
            return "redirect:/dashboard";
        } else {
            model.addAttribute("error", "Usuario o contraseña incorrectos");
            return "login";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Map<String, Object> estadisticas = estadisticaService.obtenerEstadisticasGenerales();
        model.addAttribute("estadisticas", estadisticas);
        return "dashboard";
    }

    // === CLIENTES ===
    @GetMapping("/clientes")
    public String clientes(Model model) {
        List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
        model.addAttribute("clientes", clientes);
        return "clientes";
    }

    @GetMapping("/clientes/nuevo")
    public String nuevoCliente(Model model) {
        model.addAttribute("cliente", new Cliente());
        return "cliente-form";
    }

    @PostMapping("/clientes")
    public String guardarCliente(@ModelAttribute Cliente cliente, RedirectAttributes redirectAttributes) {
        try {
            clienteService.agregarCliente(cliente);
            redirectAttributes.addFlashAttribute("success", "Cliente agregado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al agregar cliente: " + e.getMessage());
        }
        return "redirect:/clientes";
    }

    @GetMapping("/clientes/editar/{id}")
    public String editarCliente(@PathVariable int id, Model model) {
        Cliente cliente = clienteService.obtenerClientePorId(id);
        if (cliente != null) {
            model.addAttribute("cliente", cliente);
            return "cliente-form";
        }
        return "redirect:/clientes";
    }

    @PostMapping("/clientes/actualizar")
    public String actualizarCliente(@ModelAttribute Cliente cliente, RedirectAttributes redirectAttributes) {
        try {
            clienteService.actualizarCliente(cliente);
            redirectAttributes.addFlashAttribute("success", "Cliente actualizado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar cliente: " + e.getMessage());
        }
        return "redirect:/clientes";
    }

    // === MENSAJES ===
    @GetMapping("/mensajes")
    public String mensajes(Model model) {
        List<Mensaje> mensajes = mensajeService.obtenerTodasLasPlantillas();
        model.addAttribute("mensajes", mensajes);
        return "mensajes";
    }

    @GetMapping("/mensajes/nuevo")
    public String nuevoMensaje(Model model) {
        model.addAttribute("mensaje", new Mensaje());
        return "mensaje-form";
    }

    @PostMapping("/mensajes")
    public String guardarMensaje(@ModelAttribute Mensaje mensaje, RedirectAttributes redirectAttributes) {
        try {
            mensajeService.crearPlantilla(mensaje);
            redirectAttributes.addFlashAttribute("success", "Plantilla creada exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear plantilla: " + e.getMessage());
        }
        return "redirect:/mensajes";
    }

    // === ENVÍOS ===
    @GetMapping("/envios")
    public String envios(Model model) {
        List<Cliente> clientesActivos = clienteService.obtenerClientesActivos();
        List<Mensaje> plantillas = mensajeService.obtenerTodasLasPlantillas();
        model.addAttribute("clientesActivos", clientesActivos);
        model.addAttribute("plantillas", plantillas);
        return "envios";
    }

    @PostMapping("/envios/individual")
    @ResponseBody
    public Map<String, Object> enviarMensajeIndividual(@RequestBody Map<String, Object> datos) {
        try {
            int clienteId = (Integer) datos.get("clienteId");
            int mensajeId = (Integer) datos.get("mensajeId");
            String canal = (String) datos.get("canal");

            envioService.enviarMensajeIndividual(clienteId, mensajeId, canal);
            return Map.of("success", true, "message", "Mensaje enviado exitosamente");
        } catch (Exception e) {
            return Map.of("success", false, "message", "Error al enviar mensaje: " + e.getMessage());
        }
    }

    @PostMapping("/envios/masivo")
    @ResponseBody
    public Map<String, Object> enviarMensajeMasivo(@RequestBody Map<String, Object> datos) {
        try {
            int mensajeId = (Integer) datos.get("mensajeId");
            String canal = (String) datos.get("canal");

            Map<String, Integer> resultado = envioService.enviarMensajeMasivo(mensajeId, canal);
            return Map.of("success", true, "resultado", resultado);
        } catch (Exception e) {
            return Map.of("success", false, "message", "Error al enviar mensajes: " + e.getMessage());
        }
    }

    // === HISTORIAL ===
    @GetMapping("/historial")
    public String historial(Model model) {
        List<MensajeEnviado> historial = envioService.obtenerHistorial();
        model.addAttribute("historial", historial);
        return "historial";
    }

    // === ESTADÍSTICAS ===
    @GetMapping("/estadisticas")
    public String estadisticas(Model model) {
        Map<String, Object> stats = estadisticaService.obtenerEstadisticasCompletas();
        model.addAttribute("estadisticas", stats);
        return "estadisticas";
    }
}