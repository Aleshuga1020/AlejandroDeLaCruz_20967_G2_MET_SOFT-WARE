
package models;

import java.time.LocalDateTime;

public class MensajeEnviado {
    private int clienteId;
    private int mensajeId;
    private LocalDateTime fechaEnvio;
    private String estado;
    private String canal;

    public MensajeEnviado() {
        this.fechaEnvio = LocalDateTime.now();
    }

    public MensajeEnviado(int clienteId, int mensajeId, String estado, String canal) {
        this.clienteId = clienteId;
        this.mensajeId = mensajeId;
        this.estado = estado;
        this.canal = canal;
        this.fechaEnvio = LocalDateTime.now();
    }

    // Getters y Setters
    public int getClienteId() { return clienteId; }
    public void setClienteId(int clienteId) { this.clienteId = clienteId; }
    
    public int getMensajeId() { return mensajeId; }
    public void setMensajeId(int mensajeId) { this.mensajeId = mensajeId; }
    
    public LocalDateTime getFechaEnvio() { return fechaEnvio; }
    public void setFechaEnvio(LocalDateTime fechaEnvio) { this.fechaEnvio = fechaEnvio; }
    
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    
    public String getCanal() { return canal; }
    public void setCanal(String canal) { this.canal = canal; }
}
